import Foundation
import SpriteKit
extension GameScene {
    
    
    
    func flyFeatherFx() {
        if let fxFeather = SKEmitterNode(fileNamed: "fxBird.sks"){
            fxFeather.position = bird.position
            addChild(fxFeather)
            DispatchQueue.main.asyncAfter(deadline: .now() + 10.5, execute: { [] in
                fxFeather.removeFromParent()
            })
        }
    }
    func hapticTouchFx(force: UIImpactFeedbackGenerator.FeedbackStyle) {
        let impactFeedbackgenerator = UIImpactFeedbackGenerator(style: force)
        impactFeedbackgenerator.prepare()
        impactFeedbackgenerator.impactOccurred()
    }
    
    func pinkBlockFX() {
        if let pinkBlockFX = SKEmitterNode(fileNamed: "pinkBlockFX.sks"){
            pinkBlockFX.position.x = bird.position.x
            pinkBlockFX.position.y = bird.position.y - 50
            addChild(pinkBlockFX)
            DispatchQueue.main.asyncAfter(deadline: .now() + 3.0, execute: { [] in
                pinkBlockFX.removeFromParent()
            })
        }
    }
    
    
    
    func showAccessBlockFX(positionX: CGFloat, positionY: CGFloat) {
        if let showAccessBlockFX = SKEmitterNode(fileNamed: "showAccessBlockFX.sks"){
            showAccessBlockFX.position.x = CGFloat(positionX)
            showAccessBlockFX.position.y = CGFloat(positionY + (yPositionFx * coefficientSpeedNode))
            //+ 850 for 4 sec delay
            //587 for 3
            //743 for 3.5
            if gameStatus == "playing" {
                addChild(showAccessBlockFX)
            }
            
            DispatchQueue.main.asyncAfter(deadline: .now() + 2.5, execute: { [] in
                showAccessBlockFX.removeFromParent()
            })
        }
    }
    
    
    func scaleActionBlock(blockName:SKSpriteNode,scaleHight: CGFloat, scaleLow: CGFloat, scaleEnd: CGFloat) {
        if blockName.size.width >= 300 {
            blockName.run(SKAction.scale(to: 2.4, duration: 0.3))
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.15, execute: { [] in
                blockName.run(SKAction.scale(to: 1.4, duration: 0.3))
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.15, execute: { [] in
                    blockName.run(SKAction.scale(to: 1.85, duration: 0.3))
                })
            })
            
        } else {
            blockName.run(SKAction.scale(to: scaleHight, duration: 0.3))
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.15, execute: { [] in
                blockName.run(SKAction.scale(to: scaleLow, duration: 0.3))
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.15, execute: { [] in
                    blockName.run(SKAction.scale(to: scaleEnd, duration: 0.3))
                })
            })
        }
    }
    
    
    func addNumberActionFx() {
        let numberFx = SKLabelNode()
        numberFx.fontSize = 250
        numberFx.fontName = "Ubuntu-Bold"
        numberFx.text = ("\(score)")
        numberFx.zPosition = 5
        numberFx.position.x = 0
        numberFx.position.y = bird.position.y - 200
        numberFx.alpha = 0
        addChild(numberFx)
        numberFx.run(SKAction.scale(to: 0.2, duration: 0))
        numberFx.run(SKAction.scale(to: 1, duration: 0.2))
        numberFx.run(SKAction.move(by: CGVector(dx: 0, dy: 1300), duration: 3.0))
        numberFx.run(SKAction.fadeAlpha(to: 0.8, duration: 0.2))
        DispatchQueue.main.asyncAfter(deadline: .now() + 1.1, execute: { [] in
            numberFx.run(SKAction.fadeAlpha(to: 0, duration: 0.4))
        })
        DispatchQueue.main.asyncAfter(deadline: .now() + 1.6, execute: { [] in
            numberFx.removeFromParent()
        })
        
    }
    func speedFallFx() {
        if let speedFallFx = SKEmitterNode(fileNamed: "speedFallFx.sks"){
            speedFallFx.name = "speedFallFx"
            speedFallFx.position.y = -1250
            speedFallFx.position.x = 0
            //speedFallFx.particleSpeed = 60
            speedFallFx.alpha = 0.8
            speedFallFx.advanceSimulationTime(100)
           
            //speedFallFx.alpha = 0
            addChild(speedFallFx)
//            DispatchQueue.main.asyncAfter(deadline: .now() + 10.0, execute: { [] in
//                speedFallFx.removeFromParent()
//            })
        }
    }
    
    
    func confettiFx() {
        if let confettiFxRed = SKEmitterNode(fileNamed: "confettiFxRed.sks"){
            confettiFxRed.position.y = 1250
            addChild(confettiFxRed)
            DispatchQueue.main.asyncAfter(deadline: .now() + 10.0, execute: { [] in
                confettiFxRed.removeFromParent()
            })
        }
        
        if let confettiFxYellow = SKEmitterNode(fileNamed: "confettiFxYellow.sks"){
            confettiFxYellow.position.y = 1250
            addChild(confettiFxYellow)
            DispatchQueue.main.asyncAfter(deadline: .now() + 10.0, execute: { [] in
                confettiFxYellow.removeFromParent()
            })
        }
        
        if let confettiFxGreen = SKEmitterNode(fileNamed: "confettiFxGreen.sks"){
            confettiFxGreen.position.y = 1250
            addChild(confettiFxGreen)
            DispatchQueue.main.asyncAfter(deadline: .now() + 10.0, execute: { [] in
                confettiFxGreen.removeFromParent()
            })
        }
        
        
        
        
        
    }
    
    
    
    func colorizeLineYellowFx() {
        if let colorizeLineYellowFx = SKEmitterNode(fileNamed: "colorizeLineYellowFx.sks"){
            colorizeLineYellowFx.position.x = 0
            colorizeLineYellowFx.position.y = bird.position.y - 50
            
        addChild(colorizeLineYellowFx)
            DispatchQueue.main.asyncAfter(deadline: .now() + 5.5, execute: { [] in
                colorizeLineYellowFx.removeFromParent()
            })
        }
    }
    
    
    func bangWrongBlockFx(positionFxY: CGFloat, positionFxX: CGFloat) {
        if let bangWrongBlockFx = SKEmitterNode(fileNamed: "bangWrongBlockFx.sks"){
            bangWrongBlockFx.position.y = positionFxY
            bangWrongBlockFx.position.x = positionFxX
            
        addChild(bangWrongBlockFx)
            DispatchQueue.main.asyncAfter(deadline: .now() + 5.5, execute: { [] in
                bangWrongBlockFx.removeFromParent()
            })
        }
    }
    
//    func colorizeLinePinkFx(positionY: CGFloat) {
//        if let colorizeLinePinkFx = SKEmitterNode(fileNamed: "colorizeLinePinkFx.sks"){
//            colorizeLinePinkFx.position.x = 0
//            colorizeLinePinkFx.position.y = positionY
//
//        addChild(colorizeLinePinkFx)
//            DispatchQueue.main.asyncAfter(deadline: .now() + 5.5, execute: { [] in
//                colorizeLinePinkFx.removeFromParent()
//            })
//        }
//    }
    func colorizeLinePinkFx(positionX: CGFloat, positionY: CGFloat) {
        if let colorizeLinePinkFx = SKEmitterNode(fileNamed: "colorizeLinePinkFx.sks"){
            colorizeLinePinkFx.position.x = CGFloat(positionX)
            colorizeLinePinkFx.position.y = CGFloat(positionY + 800)
            
            if gameStatus == "playing" {
                addChild(colorizeLinePinkFx)
            }
            DispatchQueue.main.asyncAfter(deadline: .now() + 2.5, execute: { [] in
                colorizeLinePinkFx.removeFromParent()
            })
        }
    }
    
    
    func colorizeInWrongBlock(blockName:SKSpriteNode) {
        //white
        if gameStatus == "playing" {
            blockName.run(SKAction.colorize(with: SKColor(red: 255/255, green: 255/255, blue: 255/255, alpha: 1), colorBlendFactor: 1.0, duration: 0.5))
        }
        
    }
    
    
    
    func colorizeInAccessibleBlock(blockName:SKSpriteNode) {
        //yellow
        
        if gameStatus == "playing"{
            blockName.run(SKAction.colorize(with: SKColor(red: 223/255, green: 184/255, blue: 80/255, alpha: 1), colorBlendFactor: 0.8, duration: 0.5))
        }
    }
    
    
    
    func colorizeInActivatedBlock(blockName:SKSpriteNode) {
        //green
        
        if gameStatus == "playing" {
            blockName.run(SKAction.colorize(with: SKColor(red: 67/255, green: 163/255, blue: 147/255, alpha: 1), colorBlendFactor: 0.8, duration: 0.5))
        }
    }
    
    
    
    func colorizeInClosedAccessibleBlock(blockName:SKSpriteNode) {
        //pink
        if gameStatus == "playing" {
            blockName.run(SKAction.colorize(with: SKColor(red: 208/255, green: 119/255, blue: 197/255, alpha: 1), colorBlendFactor: 0.8, duration: 0.5))
        }
    }
    
    
    
    func shakeNode(layer:SKSpriteNode, ampX:Float, ampY:Float, numberOfShakes:Float, duration:Float) {
        var actionsArray:[SKAction] = [];
        for _ in 1...Int(numberOfShakes) {
            let moveX = Float(arc4random_uniform(UInt32(ampX))) - ampX / 2;
            let moveY = Float(arc4random_uniform(UInt32(ampY))) - ampY / 2;
            let shakeAction = SKAction.moveBy(x: CGFloat(moveX), y: CGFloat(moveY), duration: 0.02);
            shakeAction.timingMode = SKActionTimingMode.easeOut;
            actionsArray.append(shakeAction);
            actionsArray.append(shakeAction.reversed());
        }
        let actionSeq = SKAction.sequence(actionsArray);
        layer.run(actionSeq);
    }
    func shakeCamera(layer:SKCameraNode, ampX:Float, ampY:Float, numberOfShakes:Float, duration:Float) {
        var actionsArray:[SKAction] = [];
        for _ in 1...Int(numberOfShakes) {
            let moveX = Float(arc4random_uniform(UInt32(ampX))) - ampX / 2;
            let moveY = Float(arc4random_uniform(UInt32(ampY))) - ampY / 2;
            let shakeAction = SKAction.moveBy(x: CGFloat(moveX), y: CGFloat(moveY), duration: 0.02);
            shakeAction.timingMode = SKActionTimingMode.easeOut;
            actionsArray.append(shakeAction);
            actionsArray.append(shakeAction.reversed());
        }
        let actionSeq = SKAction.sequence(actionsArray);
        layer.run(actionSeq);
    }

}
