import Foundation
import SpriteKit
import GameplayKit

extension GameScene {
    
    struct Sound {
        static let point = SKAction.playSoundFileNamed("sfx_point.mp3", waitForCompletion: true)
        static let wing = SKAction.playSoundFileNamed("sfx_wing.mp3", waitForCompletion: true)
        static let swooshing = SKAction.playSoundFileNamed("sfx_swooshing.mp3", waitForCompletion: true)
        
//        static let point = Bundle.main.url(forResource: "sfx_point", withExtension: "mp3")
//        static let wing = Bundle.main.url(forResource: "sfx_wing", withExtension: "mp3")
//        static let swooshing = Bundle.main.url(forResource: "sfx_swooshing", withExtension: "mp3")
//
    }
}


