import Foundation
import SpriteKit
//BIRD
var bird = SKSpriteNode()
var speedOfBirdX:CGFloat = 700
var speedOfBirdY:CGFloat = 1260
var birdScale:CGFloat = 0.32
var directionBird:String = "none"
var fxFlyBird = SKEmitterNode()
var birdRotate = 0.15
var statusBird = "stay"
var textureAtlasBird = SKTextureAtlas()
var textureArrayBird = [SKTexture]()

extension GameScene {
    
    func createBird() {
        textureAtlasBird = SKTextureAtlas(named: "bird")
        for i in 1...textureAtlasBird.textureNames.count {
            let nameBird = "FlyingBird_\(i).png"
            textureArrayBird.append(SKTexture(imageNamed: nameBird))
        }
        bird = SKSpriteNode(imageNamed: textureAtlasBird.textureNames[0])
        bird = childNode(withName: "bird") as! SKSpriteNode
        
        bird.physicsBody = SKPhysicsBody()
        bird.physicsBody = SKPhysicsBody(circleOfRadius: bird.size.width / 4)
        bird.physicsBody?.categoryBitMask = birdCategory
        bird.physicsBody?.collisionBitMask = blockCategory | borderCatefory
        bird.physicsBody?.contactTestBitMask = blockCategory | borderCatefory
        bird.physicsBody?.affectedByGravity = false
        bird.physicsBody?.isDynamic = true
        bird.physicsBody?.allowsRotation = false
        bird.physicsBody?.mass = 0.01
        bird.physicsBody?.density = 0.4
       
        bird.setScale(birdScale)
        bird.position.y = 0
        bird.position.x = -((self.scene?.size.width)! / 4)
        bird.zPosition = 8
        
        let animationBird = SKAction.animate(with: textureArrayBird, timePerFrame: 0.020)
        let repeatActionAnimationBirdForever = SKAction.repeatForever(animationBird)
        
        bird.run(repeatActionAnimationBirdForever)
    }
    
    
    
    func toRight(){
        bird.run(SKAction.scaleY(to: birdScale, duration: 0.2))
        bird.run(SKAction.scaleX(to: birdScale, duration: 0.2))
        birdRotate = 0.15
    }
    
    func toLeft(){
        bird.run(SKAction.scaleY(to: birdScale, duration: 0.2))
        bird.run(SKAction.scaleX(to: -birdScale, duration: 0.2))
        birdRotate = -0.15
    }
    
    func turnBird() {
        if bird.position.x > (320)  {
            speedOfBirdX = -700
            toLeft()
        }

        if bird.position.x <= (-320)  {
            speedOfBirdX = 700
            toRight()
        }
    }
    
    
    
    func flyBird(velcityX: CGFloat, velcityY: CGFloat ) {
        bird.physicsBody?.affectedByGravity = true
        bird.physicsBody?.velocity = CGVector(dx: velcityX, dy: velcityY)
        bird.physicsBody?.applyImpulse(CGVector(dx: 0, dy: 0))
        
        bird.run(SKAction.rotate(toAngle: CGFloat(birdRotate), duration: 0.3))
    }
    
    
    

    
    
}
