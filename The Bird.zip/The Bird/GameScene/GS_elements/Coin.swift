import Foundation
import SpriteKit

var coinLable = SKLabelNode()

var coin = 0
var coinInGameOver = 0
var coinIcon = SKSpriteNode()
var coinLableStatus:String = "fade"
var timerFadeCoinLable = 0

extension GameScene {
//---------------------------------------animation of the coin (DID MOVE)--------------------------------
    func createCoin(positionX: CGFloat, positionY: CGFloat, delaySpawn: TimeInterval) {
        //--------------------COIN------------
        var coinNode = SKNode()
        coinNode = SKNode()
        coinNode.name = "coin"

        var coin = SKSpriteNode()
        var textureAtlasCoin = SKTextureAtlas()
        var textureArrayCoin = [SKTexture]()

        textureAtlasCoin = SKTextureAtlas(named: "coin")
        for i in 1...textureAtlasCoin.textureNames.count {
            let nameCoin = "\(i).png"
            textureArrayCoin.append(SKTexture(imageNamed: nameCoin))
        }
        coin = SKSpriteNode(imageNamed: textureAtlasCoin.textureNames[0])
        
        coin.setScale(1.0)
        coin.alpha = 1
        coin.colorBlendFactor = 0.2
        coin.position.y = positionY
        coin.position.x = positionX
        coin.zPosition = 5
            
        coin.physicsBody = SKPhysicsBody()
        coin.physicsBody = SKPhysicsBody(circleOfRadius: coin.size.width / 2)
        coin.physicsBody?.categoryBitMask = coinCategory
        coin.physicsBody?.collisionBitMask = birdCategory
        coin.physicsBody?.contactTestBitMask = birdCategory | detectCircleCategory
        coin.physicsBody?.affectedByGravity = false
        coin.physicsBody?.isDynamic = false
        
        
        DispatchQueue.main.asyncAfter(deadline: .now() + DispatchTimeInterval.milliseconds(Int(delaySpawn * 1000)), execute: { [self] in
            coinNode.addChild(coin)
            self.addChild(coinNode)
            let animationCoin = SKAction.animate(with: textureArrayCoin, timePerFrame: TimeInterval(speedCoinAnimation))
            let repeatActionAnimationCoinForever = SKAction.repeatForever(animationCoin)
                
            coin.run(repeatActionAnimationCoinForever)
            coinNode.run(moveAndRemove)
        })
    }
    
    
    
    func createCoinTrack() {
        spawnTrackCoinStatus = "active"
        createCoin(positionX: -375, positionY: -1325, delaySpawn: 0.0)
        createCoin(positionX: -125, positionY: -1325, delaySpawn: 0.2)
        createCoin(positionX: 125, positionY: -1325, delaySpawn: 0.4)
        createCoin(positionX: 375, positionY: -1325, delaySpawn: 0.6)
        DispatchQueue.main.asyncAfter(deadline: .now() + 1.5, execute: { [self] in
            createCoin(positionX: -375, positionY: -1325, delaySpawn: 0.0)
            createCoin(positionX: -125, positionY: -1325, delaySpawn: 0.2)
            createCoin(positionX: 125, positionY: -1325, delaySpawn: 0.4)
            createCoin(positionX: 375, positionY: -1325, delaySpawn: 0.6)
        })
        DispatchQueue.main.asyncAfter(deadline: .now() + 3.0, execute: { [self] in
            createCoin(positionX: -375, positionY: -1325, delaySpawn: 0.0)
            createCoin(positionX: -125, positionY: -1325, delaySpawn: 0.2)
            createCoin(positionX: 125, positionY: -1325, delaySpawn: 0.4)
            createCoin(positionX: 375, positionY: -1325, delaySpawn: 0.6)
        })
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 4.5, execute: { [self] in
            spawnTrackCoinStatus = "not active"
        })
    }
    
    
    
    func addCoin() {
        coinLable.run(SKAction.fadeAlpha(to: 0.8, duration: 0.2))
        coinIcon.run(SKAction.fadeAlpha(to: 0.8, duration: 0.2))
        coin += 1
        coinLable.text = "\(coin)"
//        DispatchQueue.main.asyncAfter(deadline: .now() + 1.0, execute: { [self] in
//            if timerFadeCoinLable == 2 {
//                    coinLable.run(SKAction.fadeAlpha(to: 0, duration: 0.4))
//                    coinIcon.run(SKAction.fadeAlpha(to: 0, duration: 0.4))
//            }
//        })
  
        
        //coinLableStatus = "show"
        timerFadeCoinLable = 0
        if timerFadeCoinLable == 0 {
            DispatchQueue.main.asyncAfter(deadline: .now() + 1.0, execute: { [] in
                timerFadeCoinLable += 1
            })
        }
        DispatchQueue.main.asyncAfter(deadline: .now() + 2.0, execute: { [] in
            if timerFadeCoinLable == 1 {
                timerFadeCoinLable += 1
            }
        })
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 2.1, execute: { [] in
            if timerFadeCoinLable == 2 {
                coinLable.run(SKAction.fadeAlpha(to: 0, duration: 0.4))
                coinIcon.run(SKAction.fadeAlpha(to: 0, duration: 0.4))
                timerFadeCoinLable = 0
            }
        })
        
        
        
        
    }
    
    
    
}
