import Foundation
import SpriteKit
extension GameScene {
    func createTapToStartLabel() {
        tapToStartLabel = self.childNode(withName: "tapToStartLabel") as! SKLabelNode
        tapToStartLabel.xScale = 0.5
        tapToStartLabel.position.y = -550
    }
    
    
    
    func createMainScoreLable() {
        mainScoreLabel = self.childNode(withName: "mainScoreLabel") as! SKLabelNode
        mainScoreLabel.text = "\(score)"
        mainScoreLabel.alpha = 0
    }
    
    
    
    func createCoinLable() {
        coinIcon = self.childNode(withName: "coinIcon") as! SKSpriteNode
        coinIcon.alpha = 0
        coinLable = self.childNode(withName: "coinLable") as! SKLabelNode
        coinLable.text = "\(score)"
        coinLable.alpha = 0
    }
    
    
    
}
