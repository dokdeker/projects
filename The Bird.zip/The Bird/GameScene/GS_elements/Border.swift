import Foundation
import SpriteKit

extension GameScene {
    func createBorder(side: SKSpriteNode, positionX: CGFloat , positionY: CGFloat, zRotation: CGFloat) {
        side.size.width = 3000
        side.size.height = 50
        side.position.x = positionX
        side.alpha = 0
        side.position.y = positionY
        side.zPosition = 1
        side.zRotation = zRotation
        
        side.physicsBody = SKPhysicsBody()
        
        side.physicsBody = SKPhysicsBody(rectangleOf: side.size)
        side.physicsBody?.categoryBitMask = borderCatefory
        side.physicsBody?.collisionBitMask = birdCategory
        side.physicsBody?.contactTestBitMask = birdCategory
        side.physicsBody?.isDynamic = false
        side.physicsBody?.affectedByGravity = false
        side.physicsBody?.allowsRotation = false
        side.physicsBody?.restitution = 0.8
        side.physicsBody?.friction = 5
        addChild(side)
    }
    
    
    
    func createBorders() {
        let borderLeft = SKSpriteNode(imageNamed: "block1х3")
        createBorder(side: borderLeft, positionX: -565, positionY: 0, zRotation: .pi / 2)
        
        let borderRight = SKSpriteNode(imageNamed: "block1х3")
        createBorder(side: borderRight, positionX: 565, positionY: 0, zRotation: .pi / 2)
        
        let borderTop = SKSpriteNode(imageNamed: "block1х3")
        createBorder(side: borderTop, positionX: 0, positionY: 1500, zRotation: 0)
    }
}
