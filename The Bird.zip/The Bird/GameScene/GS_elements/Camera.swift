import Foundation
import SpriteKit

let gameSceneCamera = SKCameraNode()

extension GameScene {
    
    
    
    func createCamera() {
        addChild(gameSceneCamera)
        scene?.camera = gameSceneCamera
    }
    
    func zoomOutToActionCamera(zoomOutTo: CGFloat, duration: TimeInterval) {
        gameSceneCamera.run(SKAction.scale(to: zoomOutTo, duration: duration))
        
    }
    
    func zoomInOutActionCamera(){
        if UIDevice.current.userInterfaceIdiom == .phone {
            gameSceneCamera.run(SKAction.scale(to: 0.90, duration: 0.1))
            DispatchQueue.main.asyncAfter(deadline: .now()+0.1) {
                gameSceneCamera.run(SKAction.scale(to: 1, duration: 0.1))
            }
        } else if UIDevice.current.userInterfaceIdiom == .pad {
            gameSceneCamera.run(SKAction.scale(to: 1.6, duration: 0.1))
            DispatchQueue.main.asyncAfter(deadline: .now()+0.1) {
                gameSceneCamera.run(SKAction.scale(to: 1.7, duration: 0.1))
            }
        }
    }
    
    
    
    
    
    
    
    
    
}
