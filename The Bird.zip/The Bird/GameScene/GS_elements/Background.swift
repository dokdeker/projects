import Foundation
import SpriteKit

var moveAndRemoveBgBlock1 = SKAction()
var moveAndRemoveBgBlock2 = SKAction()
var lastPartPositionBlock1 = 3
var lastPartPositionBlock2 = 3
var randomPartPosition = 0
var randomPartPosition2 = 0

extension GameScene {
    func antiRepeatSpawnPositionX1(amountParts: Int, weightSceen: Int, node: SKSpriteNode){
        randomPartPosition = Int.random(in: 1...amountParts)
        while randomPartPosition == lastPartPositionBlock1 || randomPartPosition == lastPartPositionBlock1 + 1 || randomPartPosition == lastPartPositionBlock1 - 1{
            randomPartPosition = Int.random(in: 1...amountParts)
        }
        lastPartPositionBlock1 = randomPartPosition
        //print(randomPartPosition)
        let weightScreen = weightSceen
        let onePart = weightScreen / amountParts
        let endPointPart = randomPartPosition * onePart
        let startPointPart = endPointPart - onePart
        let addVariableRandomPosition = Int.random(in: -100 ... 100)
        let positionBlockX = ((startPointPart + (onePart / 2))) - (weightScreen / 2) + addVariableRandomPosition
        node.position = CGPoint(x: positionBlockX, y: Int.random(in: -1500 ... -1400))
    }
    
    func antiRepeatSpawnPositionX2(amountParts: Int, weightSceen: Int, node: SKSpriteNode){
        randomPartPosition = Int.random(in: 1...amountParts)
        while randomPartPosition == lastPartPositionBlock2 || randomPartPosition == lastPartPositionBlock2 + 1 || randomPartPosition == lastPartPositionBlock2 - 1{
            randomPartPosition = Int.random(in: 1...amountParts)
        }
        lastPartPositionBlock2 = randomPartPosition
        //print(randomPartPosition)
        let weightScreen = weightSceen
        let onePart = weightScreen / amountParts
        let endPointPart = randomPartPosition * onePart
        let startPointPart = endPointPart - onePart
        let addVariableRandomPosition = Int.random(in: -100 ... 100)
        let positionBlockX = ((startPointPart + (onePart / 2))) - (weightScreen / 2) + addVariableRandomPosition
        node.position = CGPoint(x: positionBlockX, y: Int.random(in: -1500 ... -1400))
    }
    







    func createBgBlocks1() {
        let BgBlock = SKNode()
        BgBlock.name = "BgBlock"
        let RandomBlock = (Int.random(in: 1...2))
        let block = SKSpriteNode(imageNamed: "block1х\(RandomBlock)")
        let ScaleBlock:CGFloat = 0.8
        block.zPosition = 1
        block.xScale = ScaleBlock
        block.yScale = ScaleBlock
        block.zRotation = .pi / CGFloat((Int.random(in: 2...10)))


        if UIDevice.current.userInterfaceIdiom == .phone {
            antiRepeatSpawnPositionX1(amountParts: 5, weightSceen: 1080, node: block)
        } else if UIDevice.current.userInterfaceIdiom == .pad {
            antiRepeatSpawnPositionX1(amountParts: 7, weightSceen: 1536, node: block)
        }



        block.run(SKAction.rotate(toAngle: (CGFloat.random(in: -50...50)), duration: 80))

        block.run(SKAction.colorize(with: SKColor(red: 185/255, green: 145/255, blue: 185/255, alpha: 1), colorBlendFactor: 0.7, duration: 0))


        BgBlock.addChild(block)
        BgBlock.run(moveAndRemoveBgBlock1)
        self.addChild(BgBlock)
    }



    func spawnBgBlocks1() {
        let spawnBgBlock = SKAction.run({
                    () in
            self.createBgBlocks1()
        })
        let pauseAfterSpawnBlock = SKAction.wait(forDuration: 4)
        let SequenceSpawnAndPauseBlock = SKAction.sequence([spawnBgBlock, pauseAfterSpawnBlock])
        let Sequence_repitForeverSpawnBlock = SKAction.repeatForever(SequenceSpawnAndPauseBlock)
        self.run(Sequence_repitForeverSpawnBlock)
        let moveBgBlock = SKAction.moveBy(x: 0, y: moveByLine, duration: moveLineSpeed * 2)
        let removeBgBlock = SKAction.removeFromParent()
        moveAndRemoveBgBlock1 = SKAction.sequence([moveBgBlock, removeBgBlock])
    }


    func createBgBlocks2() {
        let BgBlock = SKNode()
        BgBlock.name = "BgBlock"
        let RandomBlock = (Int.random(in: 1...2))
        let block = SKSpriteNode(imageNamed: "block1х\(RandomBlock)")
        let randomScaleBlock:CGFloat = 0.53
        block.zPosition = 0
        block.xScale = randomScaleBlock
        block.yScale = randomScaleBlock
        block.zRotation = .pi / CGFloat((Int.random(in: 2...10)))


        if UIDevice.current.userInterfaceIdiom == .phone {
            antiRepeatSpawnPositionX2(amountParts: 5, weightSceen: 1080, node: block)
        } else if UIDevice.current.userInterfaceIdiom == .pad {
            antiRepeatSpawnPositionX2(amountParts: 7, weightSceen: 1536, node: block)
        }



        block.run(SKAction.rotate(toAngle: (CGFloat.random(in: -50...50)), duration: 80))
        block.run(SKAction.colorize(with: SKColor(red: 76/255, green: 48/255, blue: 88/255, alpha: 1), colorBlendFactor: 0.95, duration: 0))


        BgBlock.addChild(block)
        BgBlock.run(moveAndRemoveBgBlock2)
        self.addChild(BgBlock)
    }

    func spawnBgBlocks2() {
        let spawnBgBlock = SKAction.run({
                    () in
            self.createBgBlocks2()
        })
        let pauseAfterSpawnBlock = SKAction.wait(forDuration: 3)
        let SequenceSpawnAndPauseBlock = SKAction.sequence([spawnBgBlock, pauseAfterSpawnBlock])
        let Sequence_repitForeverSpawnBlock = SKAction.repeatForever(SequenceSpawnAndPauseBlock)
        self.run(Sequence_repitForeverSpawnBlock)
        let moveBgBlock = SKAction.moveBy(x: 0, y: moveByLine, duration: moveLineSpeed * 3)
        let removeBgBlock = SKAction.removeFromParent()
        moveAndRemoveBgBlock2 = SKAction.sequence([moveBgBlock, removeBgBlock])
    }
    
    
    
    
    
    func preSpawnBgBlocks1() {
        for partVertical in 1...7 {
            let BgBlock = SKNode()
            BgBlock.name = "BgBlock"
            let RandomBlock = (Int.random(in: 1...2))
            let block = SKSpriteNode(imageNamed: "block1х\(RandomBlock)")
            let ScaleBlock:CGFloat = 0.8
            
            block.zPosition = 1
            block.xScale = ScaleBlock
            block.yScale = ScaleBlock
            block.zRotation = .pi / CGFloat((Int.random(in: 2...10)))
            
            
            if UIDevice.current.userInterfaceIdiom == .phone {
                block.position.x = CGFloat.random(in: -450...450)
            } else if UIDevice.current.userInterfaceIdiom == .pad {
                block.position.x = CGFloat.random(in: -600...600)
            }
            if partVertical == 1 {
                block.position.y = CGFloat.random(in: 836...1170)
            }
            if partVertical == 2 {
                block.position.y = CGFloat.random(in: 502...836)
            }
            if partVertical == 3 {
                block.position.y = CGFloat.random(in: 168...502)
            }
            if partVertical == 4 {
                block.position.y = CGFloat.random(in: -166...168)
            }
            if partVertical == 5 {
                block.position.y = CGFloat.random(in: -500 ... -166)
            }
            if partVertical == 6 {
                block.position.y = CGFloat.random(in: -834 ... -500)
            }
            if partVertical == 7 {
                block.position.y = CGFloat.random(in: -1168 ... -834)
            }
            
            block.run(SKAction.rotate(toAngle: (CGFloat.random(in: -50...50)), duration: 80))
            block.run(SKAction.colorize(with: SKColor(red: 185/255, green: 145/255, blue: 185/255, alpha: 1), colorBlendFactor: 0.7, duration: 0))
            
            block.run(SKAction.moveBy(x: 0, y: moveByLine, duration: moveLineSpeed * 2))

            BgBlock.addChild(block)
//            BgBlock.run(moveAndRemoveBgBlock1)
            self.addChild(BgBlock)
        }
    }
    
    
    
    
    func preSpawnBgBlocks2() {
        for partVertical in 1...12 {
            let BgBlock = SKNode()
            BgBlock.name = "BgBlock"
            let RandomBlock = (Int.random(in: 1...2))
            let block = SKSpriteNode(imageNamed: "block1х\(RandomBlock)")
            let ScaleBlock:CGFloat = 0.533
            
            block.zPosition = 0
            block.xScale = ScaleBlock
            block.yScale = ScaleBlock
            block.zRotation = .pi / CGFloat((Int.random(in: 2...10)))
            
            
            if UIDevice.current.userInterfaceIdiom == .phone {
                block.position.x = CGFloat.random(in: -450...450)
            } else if UIDevice.current.userInterfaceIdiom == .pad {
                block.position.x = CGFloat.random(in: -600...600)
            }
            if partVertical == 1 {
                block.position.y = CGFloat.random(in: 975...1170)
            }
            if partVertical == 2 {
                block.position.y = CGFloat.random(in: 780...975)
            }
            if partVertical == 3 {
                block.position.y = CGFloat.random(in: 585...780)
            }
            if partVertical == 4 {
                block.position.y = CGFloat.random(in: 390...585)
            }
            if partVertical == 5 {
                block.position.y = CGFloat.random(in: 195 ... 390)
            }
            if partVertical == 6 {
                block.position.y = CGFloat.random(in: 0 ... 195)
            }
            if partVertical == 7 {
                block.position.y = CGFloat.random(in: -195 ... 0)
            }
            if partVertical == 8 {
                block.position.y = CGFloat.random(in: -390 ... -195)
            }
            if partVertical == 9 {
                block.position.y = CGFloat.random(in: -585 ... -390)
            }
            if partVertical == 10 {
                block.position.y = CGFloat.random(in: -780 ... -585)
            }
            if partVertical == 11 {
                block.position.y = CGFloat.random(in: -975 ... -780)
            }
            if partVertical == 12 {
                block.position.y = CGFloat.random(in: -1170 ... -975)
            }
            
            block.run(SKAction.rotate(toAngle: (CGFloat.random(in: -50...50)), duration: 80))
            block.run(SKAction.colorize(with: SKColor(red: 76/255, green: 48/255, blue: 88/255, alpha: 1), colorBlendFactor: 0.95, duration: 0))
            
            block.run(SKAction.moveBy(x: 0, y: moveByLine, duration: moveLineSpeed * 3))

            BgBlock.addChild(block)
            self.addChild(BgBlock)
        }
    }
    
    
    
    
    
    func createBackground() {
        bg = self.childNode(withName: "bg") as! SKSpriteNode
        
            bg.size.height = 3000
            bg.size.width = 2250
        
        bg.alpha = 1
        bg.zPosition = -2
        bg.position = CGPoint(x: 0, y: 0)
        bg.anchorPoint = CGPoint(x: 0.5, y: 0.5)
    }
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    

}
