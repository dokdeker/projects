import SpriteKit
import GameplayKit

class GameScene: SKScene, SKPhysicsContactDelegate {
    var gameViewControllerBridge: GameViewController!
    var gameOverViewControllerBridge: GameOverViewController!
    var menuViewControllerBridge: MenuViewController!
    
    var lastLineBlockWas = 0
    var lastAmountCoin = 0
    var spawnTrackCoinStatus = "not active"
    
    var bg = SKSpriteNode()
    var gameStatus:String = "wait"
    
    
    //STARS
    var stars = SKSpriteNode()
    var stars2 = SKSpriteNode()
    var moveBgStars:String = "yes"
    var speedStars = 0.8

    
    //SCORE & MAIN SCORE LABEL
    var score = 0
    var allScore = 0
    
    var bestScore = 0
    var scoreInGameOver = 0
    var mainScoreLabel = SKLabelNode()
    
    
    var allCoin = 0
    
    //TAP TO START
    var tapToStartLabel = SKLabelNode()
    var tapToStartLabelAnimation = "full"
    
    
    var indexGame = 0
    var indexGameOnStart = 0
    
    //PHYSICS CATEGORY
    let birdCategory: UInt32 = 0x1 << 1
    let blockCategory: UInt32 = 0x1 << 2
    let accessibleBlockCategory : UInt32 = 0x1 << 3
    
    let closedAccessibleBlockCategory : UInt32 = 0x1 << 4
    let closedLineBlockCategory : UInt32 = 0x1 << 5
    let activatedBlockCategory : UInt32 = 0x1 << 11
    
    let coinCategory: UInt32 = 0x1 << 7
    
    let detectBlockCategory: UInt32 = 0x1 << 6
    let detectCircleCategory: UInt32 = 0x1 << 8
    
    let ghostCategory: UInt32 = 0x1 << 10
    
    let borderCatefory: UInt32 = 0x1 << 12
    
    let detectBlockClosedLineCategory: UInt32 = 0x1 << 9
    



    
    var moveAndRemove = SKAction()
    var upAndDown = SKAction()
    
    
    
    
    //BLOCK
    var lineBlock = SKNode()
    var moveLineSpeed:TimeInterval = 10
    var moveByLine:CGFloat = 3000
    
   

    //var explosionSequence: UIImageView!
    var startIndex = 0
    var endIndex = 0
    var remainderIndex:Double = 0
    var timeDurationRingAnimation = 1.0
    var imgListArray :NSMutableArray = []
    var images = [UIImage]()
    var images2 = [UIImage]()
    var animatedImage: UIImage!
    var birdLvl = 1
    var birdExp = 0
    var exp = 24
    var lvlLader = [0,1000,2000,3000,4000,5000,6000,7000,8000,9000,10000]
    
    
    var detectBlock = SKSpriteNode(color: .red, size: CGSize(width: 1080, height: 20))
    
    var detectCircle = SKSpriteNode()
    
    
    var scaleInterface = 1.0
    
    
    var coefficientSpeedNode:CGFloat = 1.0
    var speedCoinAnimation:CGFloat = 0.025
    
    
    
    var timeDelaySpawnBlock:CGFloat = 4.0
    var timeDelaySpawnLine:TimeInterval = 1.5
    var yPositionFx:CGFloat = 787.5
//    var logoRhomb = SKSpriteNode(color: .black, size: CGSize(width: 2000, height: 2000))
//    var logoLabel1 = UILabel(frame: CGRect(x: 0, y: 0, width: 300, height: 50))
//    var logoLabel2 = UILabel(frame: CGRect(x: 0, y: 0, width: 300, height: 200))
    
    //    struct PhysicsCatagory {
//        static let Bird : UInt32 = 0x1 << 1
//        //static let Ground : UInt32 = 0x1 << 2
//        static let Wall : UInt32 = 0x1 << 2
//        //static let Score : UInt32 = 0x1 << 4
//    }
    
   
    
    
//----------------------------------------------- DID MOVE ------------------------------------------------
override func didMove(to view: SKView) {
    self.physicsWorld.contactDelegate = self
    interfaceDevices()
    createCamera()
    createBackground()
    createCoinLable()
    createMainScoreLable()
    createTapToStartLabel()
    createDetectBlock()
    createDetectCircle()
    speedFallFx()
    
    
        
    createBird()
    createBorders()
    fadeInMenuAfterLauchScreenAnimations()
    
    preSpawnBgBlocks1()
    preSpawnBgBlocks2()
    
    spawnBgBlocks1()
    spawnBgBlocks2()
    
    
    
//    for i in 0 ... 100 {
//        images.append(UIImage(named: "\(i)diagr.png")!)
//    }
    
    
    
    
    
}
    
 
    
    
//------------------------------------------- UPDATE ---------------------------
    override func update(_ currentTime: TimeInterval) {
        speedLine()
        detectCircle.position.x = 0
        
//        if detectBlockClosedLine.frame.intersects(self.lineBlock.frame){
//            print("ggggggggg")
//
//        }

        
        
        if bird.position.y > 560 {
            mainScoreLabel.run(SKAction.fadeAlpha(to: 0, duration: 0.1))
        }
        
        

        if gameStatus == "Game over" {
            DispatchQueue.main.asyncAfter(deadline: .now() + 1.2, execute: { [self] in
                 
                if gameStatus == "Game over" && allScore > 0  {
                        scoreInGameOver += 1
                        print("scoreInGameOver: \(scoreInGameOver)")
                        gameOverViewControllerBridge.gameOverScoreLaber.text = "\(scoreInGameOver)"
                        gameOverViewControllerBridge.bestScoreLabel.text = "\(bestScore)"
                        allScore -= 1
                        print("allScore: \(allScore)")
                }
                
                if gameStatus == "Game over" && allCoin != 0  {
                    coinInGameOver += 1
                    gameOverViewControllerBridge.gameOverCoinLabel.text = "\(coinInGameOver)"
                    allCoin -= 1
                }
            })
        }
        
        
        
        if gameStatus == "playing" && bird.position.y < -1270 {
            funcGameOver()
        }
        
//--------------------------------------- start func (UPDATE)-------------------------------------------
        func moveDetectBlock() {
            detectBlock.physicsBody?.allowsRotation = false
            detectBlock.position.y = bird.position.y
            detectBlock.position.x = 0
        }
        
        
        turnBird()
        letsStarsMove()
        moveDetectBlock()
        
        
        if gameStatus == "wait" {
            tapToStartAnimation()
        }
        
        if gameStatus == "playing" {
            hideObjectsForStart()
        }
}
    
//-------------------------------func (UPDATE) -----------------------------------
    
//--------------------[END] CIRCLE [END]-----------------
//--------------------[END] DID BEHEN TOUCH[END]-----------------
    
    
    
    func detectCircleCleanOtherBlock(){
        detectCircle.physicsBody?.isDynamic = true
        detectCircle.position.y = 2150
        detectCircle.run(SKAction.moveBy(x: 0, y: -4140, duration: 0.3))
        //print("шар долетел до -2140")
    }
    
    
    
    func restartGame() {
        
        bird.alpha = 0
        bird.run(SKAction.fadeAlpha(to: 1.0, duration: 0.5))
        bird.physicsBody?.affectedByGravity = false
        bird.physicsBody?.isDynamic = false
        score = 0
        coin = 0
        lastLineBlockWas = 0
        mainScoreLabel.text = "\(score)"
        mainScoreLabel.alpha = 0
        
        lineBlock.removeFromParent()
        
        
        speedOfBirdX = 700
        bird.run(SKAction.rotate(toAngle: 0, duration: 0.2))
        bird.physicsBody?.categoryBitMask = birdCategory
        bird.physicsBody?.collisionBitMask = blockCategory | borderCatefory
        bird.physicsBody?.contactTestBitMask = blockCategory | borderCatefory
        bird.physicsBody?.affectedByGravity = false
        bird.physicsBody?.isDynamic = true
        bird.setScale(birdScale)
        birdRotate = 0.15
        bird.run(SKAction.scaleX(to: birdScale, duration: 0.2))
        bird.position.y = 0
        
        bird.position.x = -250
        bird.zPosition = 8
        
        detectCircle.position.x = 0
        detectCircle.position.y = 960
        detectCircle.physicsBody?.affectedByGravity = false
        detectCircle.physicsBody?.isDynamic = false
        
        
        
        detectBlock.physicsBody?.categoryBitMask = detectBlockCategory
        amountActivatedBlocks = 0
        tapToStartLabel.run(SKAction.fadeAlpha(to: 1, duration: 0.2))
        
        moveBgStars = "yes"
        speedStars = 0.8
        
        firstLineHasBlocks = 3
        lastAmountCoin = 0
        
        gameStatus = "wait"
    }
    
    
    
    func funcGameOver() {
        indexGame += 1
        gameStatus = "Game over"
        allScore = score
        allCoin = coin
        scoreInGameOver = 0
        coinInGameOver = 0
        detectCircleCleanOtherBlock()
        speedStars = 0.8
        
        
        if score > bestScore {
            gameOverNewRecordAnimatonWindow()
        } else {
            gameOverAnimatonWindow()
        }
        
        
        if bird.position.y <= -1300 {
            bird.run(SKAction.fadeAlpha(to: 0, duration: 0))
        }
        
        
//        DispatchQueue.main.asyncAfter(deadline: .now() + 2.0, execute: { [self] in
//            lineBlock.run(SKAction.fadeAlpha(to: 0, duration: 0.2))
//
//            lineBlock.removeFromParent()
//        })
        
        
        enumerateBestScore()
        
        
        
        enumerateChildNodes(withName: "lineBlock", using: ({
            (node, error) in
//            DispatchQueue.main.asyncAfter(deadline: .now() + 0.3, execute: { [] in
//                node.speed = 0
//            })
            self.removeAllActions()
            self.spawnBgBlocks1()
            self.spawnBgBlocks2()
        }))
        
        enumerateChildNodes(withName: "BgBlock", using: ({
            (node, error) in
            node.speed = 1
        }))
        enumerateChildNodes(withName: "coin", using: ({
            (node, error) in
            //node.run(SKAction.fadeAlpha(to: 0, duration: 0.3))
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.3, execute: { [] in
                node.removeFromParent()
            })
        }))
        mainScoreLabel.run(SKAction.fadeAlpha(to: 0, duration: 0.2))
    }
    
    
    
    func addScore() {
        score += 1
        mainScoreLabel.text = "\(score)"
        colorizeLineYellowFx()
        addNumberActionFx()
    }
    
    
    
    func enumerateBestScore() {
        if score > bestScore {
            bestScore = score
//            print(" score \(score)")
//            print(" bestScore \(bestScore)")
        }
    }

    
    
    
    




}
        
    

