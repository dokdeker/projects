import Foundation
import SpriteKit

extension GameScene {
    
    func hideGamePlay() {
        self.tapToStartLabel.run(SKAction.fadeAlpha(to: 0, duration: 0))
        bird.run(SKAction.fadeAlpha(to: 0, duration: 0))
        
    }
    
    
    
    func fadeOutMenuBeforeGamePlayAnimation() {
        UIView.animate(withDuration: 0.3, delay: 0.1, options: .curveEaseOut) { [self] in
            menuViewControllerBridge.rhomb.transform = CGAffineTransform(scaleX: 0.8, y: 0.8).rotated(by: .pi / 2)
            menuViewControllerBridge.rhomb.alpha = 0
            menuViewControllerBridge.rhomb.center.y -= 25
            
            menuViewControllerBridge.falling.alpha = 0
            menuViewControllerBridge.falling.transform = CGAffineTransform(scaleX: 0.8, y: 0.8)
            menuViewControllerBridge.falling.center.y -= 25
            
            menuViewControllerBridge.bird.alpha = 0
            menuViewControllerBridge.bird.transform = CGAffineTransform(scaleX: 0.8, y: 0.8)
            menuViewControllerBridge.bird.center.y -= 25
        }
        
        
        
        
        UIView.animate(withDuration: 0.2, delay: 0.0, options: .curveEaseOut) { [self] in
            menuViewControllerBridge.playBTN.center.y += 25
            menuViewControllerBridge.playBTN.alpha = 0
            menuViewControllerBridge.playBTN.transform = CGAffineTransform(scaleX: 0.8, y: 0.8)
        }
        
        
        UIView.animate(withDuration: 0.3, delay: 0.1, options: .curveEaseOut) { [self] in
            menuViewControllerBridge.marketBTN.center.y += 25
            menuViewControllerBridge.marketBTN.alpha = 0
            menuViewControllerBridge.marketBTN.transform = CGAffineTransform(scaleX: 0.8, y: 0.8)
        
        
            menuViewControllerBridge.laderBTN.center.y += 25
            menuViewControllerBridge.laderBTN.alpha = 0
            menuViewControllerBridge.laderBTN.transform = CGAffineTransform(scaleX: 0.8, y: 0.8)
        
        
            menuViewControllerBridge.settingsBTN.center.y += 25
            menuViewControllerBridge.settingsBTN.alpha = 0
            menuViewControllerBridge.settingsBTN.transform = CGAffineTransform(scaleX: 0.8, y: 0.8)
        
        
            menuViewControllerBridge.noADSBTN.center.y += 25
            menuViewControllerBridge.noADSBTN.alpha = 0
            menuViewControllerBridge.noADSBTN.transform = CGAffineTransform(scaleX: 0.8, y: 0.8)
        }
    }
    
    
    
    func fadeInMenuAfterGameOverAnimations() {
        self.gameViewControllerBridge.addChild(self.menuViewControllerBridge)
        self.gameViewControllerBridge.view.addSubview(self.menuViewControllerBridge.view)
        self.menuViewControllerBridge.view.frame = self.gameViewControllerBridge.view.bounds
        
        menuViewControllerBridge.rhomb.center.y += 25
        menuViewControllerBridge.falling.center.y += 25
        menuViewControllerBridge.bird.center.y += 25
        menuViewControllerBridge.playBTN.center.y -= 25
        menuViewControllerBridge.marketBTN.center.y -= 25
        menuViewControllerBridge.laderBTN.center.y -= 25
        menuViewControllerBridge.settingsBTN.center.y -= 25
        menuViewControllerBridge.noADSBTN.center.y -= 25
    
    
        menuViewControllerBridge.rhomb.transform = CGAffineTransform(scaleX: 0.2, y: 0.2).rotated(by: 0)
        menuViewControllerBridge.rhomb.alpha = 0
        
        menuViewControllerBridge.falling.alpha = 0
        menuViewControllerBridge.falling.transform = CGAffineTransform(scaleX: 0.2, y: 0.2)
        
        menuViewControllerBridge.bird.alpha = 0
        menuViewControllerBridge.bird.transform = CGAffineTransform(scaleX: 0.2, y: 0.2)
        
        UIView.animate(withDuration: 0.3, delay: 0, options: .curveEaseOut) { [self] in
            menuViewControllerBridge.rhomb.transform = CGAffineTransform(scaleX: 1.0, y: 1.0).rotated(by: .pi / 2)
            menuViewControllerBridge.rhomb.alpha = 1
            
            menuViewControllerBridge.falling.alpha = 1
            menuViewControllerBridge.falling.transform = CGAffineTransform(scaleX: 1.0, y: 1.0)
            
            menuViewControllerBridge.bird.alpha = 1
            menuViewControllerBridge.bird.transform = CGAffineTransform(scaleX: 1.0, y: 1.0)
        }
        fadeInButtonsAnimations()
        
    }
    
    
    
    func fadeInMenuAfterLauchScreenAnimations() {
        hideGamePlay()
        gameStatus = "menu"
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.0, execute: { [self] in
            gameViewControllerBridge.addChild(menuViewControllerBridge)
            gameViewControllerBridge.view.addSubview(menuViewControllerBridge.view)
            menuViewControllerBridge.view.frame = gameViewControllerBridge.view.bounds
            //menuViewControllerBridge
            
            menuViewControllerBridge.view.transform = CGAffineTransform(scaleX: CGFloat(scaleInterface), y: CGFloat(scaleInterface))
            
            menuViewControllerBridge.marketBTN.alpha = 0
            menuViewControllerBridge.laderBTN.alpha = 0
            menuViewControllerBridge.settingsBTN.alpha = 0
            menuViewControllerBridge.noADSBTN.alpha = 0
            menuViewControllerBridge.playBTN.alpha = 0
            menuViewControllerBridge.falling.alpha = 0
            menuViewControllerBridge.bird.alpha = 0
            menuViewControllerBridge.view.alpha = 1
            menuViewControllerBridge.rhomb.transform = CGAffineTransform(scaleX: 10.0, y: 10.0)
            
            menuViewControllerBridge.falling.transform = CGAffineTransform(scaleX: 0.3, y: 0.3)
            menuViewControllerBridge.bird.transform = CGAffineTransform(scaleX: 0.3, y: 0.3)
            
            UIView.animate(withDuration: 1.0, delay: 0, options: .curveEaseOut) { [self] in
                menuViewControllerBridge.rhomb.transform = CGAffineTransform(rotationAngle: .pi / 2)
            }
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.4, execute: { [self] in
                fadeInButtonsAnimations()
            })
        })
    }
    
    
    
    func fadeInButtonsAnimations() {
        menuViewControllerBridge.marketBTN.alpha = 0
        menuViewControllerBridge.laderBTN.alpha = 0
        menuViewControllerBridge.settingsBTN.alpha = 0
        menuViewControllerBridge.noADSBTN.alpha = 0
        menuViewControllerBridge.playBTN.alpha = 0
        
        menuViewControllerBridge.playBTN.center.y -= 25
        menuViewControllerBridge.playBTN.transform = CGAffineTransform(scaleX: 0.8, y: 0.8)
        
        menuViewControllerBridge.marketBTN.center.y -= 25
        menuViewControllerBridge.marketBTN.transform = CGAffineTransform(scaleX: 0.8, y: 0.8)
        
        menuViewControllerBridge.laderBTN.center.y -= 25
        menuViewControllerBridge.laderBTN.transform = CGAffineTransform(scaleX: 0.8, y: 0.8)
        
        menuViewControllerBridge.settingsBTN.center.y -= 25
        menuViewControllerBridge.settingsBTN.transform = CGAffineTransform(scaleX: 0.8, y: 0.8)
        
        menuViewControllerBridge.noADSBTN.center.y -= 25
        menuViewControllerBridge.noADSBTN.transform = CGAffineTransform(scaleX: 0.8, y: 0.8)
        
        
        
        UIView.animate(withDuration: 0.3, delay: 0.0, options: .curveEaseOut) { [self] in
            menuViewControllerBridge.falling.alpha = 1
            menuViewControllerBridge.falling.transform = CGAffineTransform(scaleX: 1.2, y: 1.2)
        }
        
        UIView.animate(withDuration: 0.3, delay: 0.2, options: .curveEaseOut) { [self] in
            menuViewControllerBridge.bird.alpha = 1
            menuViewControllerBridge.bird.transform = CGAffineTransform(scaleX: 1.2, y: 1.2)
        }
        
        
        
        UIView.animate(withDuration: 0.2, delay: 0.1, options: .curveEaseOut) { [self] in
            menuViewControllerBridge.falling.alpha = 1
            menuViewControllerBridge.falling.transform = CGAffineTransform(scaleX: 1.0, y: 1.0)
        }
        
        UIView.animate(withDuration: 0.2, delay: 0.1, options: .curveEaseOut) { [self] in
            menuViewControllerBridge.bird.alpha = 1
            menuViewControllerBridge.bird.transform = CGAffineTransform(scaleX: 1.0, y: 1.0)
        }
        
        UIView.animate(withDuration: 0.4, delay: 0.2, options: .curveEaseOut) { [self] in
            menuViewControllerBridge.playBTN.center.y += 25
            menuViewControllerBridge.playBTN.alpha = 1
            menuViewControllerBridge.playBTN.transform = CGAffineTransform(scaleX: 1.0, y: 1.0)
        }
        
        
        UIView.animate(withDuration: 0.3, delay: 0.3, options: .curveEaseOut) { [self] in
            menuViewControllerBridge.marketBTN.center.y += 25
            menuViewControllerBridge.marketBTN.alpha = 1
            menuViewControllerBridge.marketBTN.transform = CGAffineTransform(scaleX: 1.0, y: 1.0)
        }
        UIView.animate(withDuration: 0.3, delay: 0.3, options: .curveEaseOut) { [self] in
            menuViewControllerBridge.laderBTN.center.y += 25
            menuViewControllerBridge.laderBTN.alpha = 1
            menuViewControllerBridge.laderBTN.transform = CGAffineTransform(scaleX: 1.0, y: 1.0)
        }
        UIView.animate(withDuration: 0.3, delay: 0.3, options: .curveEaseOut) { [self] in
            menuViewControllerBridge.settingsBTN.center.y += 25
            menuViewControllerBridge.settingsBTN.alpha = 1
            menuViewControllerBridge.settingsBTN.transform = CGAffineTransform(scaleX: 1.0, y: 1.0)
        }
        UIView.animate(withDuration: 0.3, delay: 0.4, options: .curveEaseOut) { [self] in
            menuViewControllerBridge.noADSBTN.center.y += 25
            menuViewControllerBridge.noADSBTN.alpha = 1
            menuViewControllerBridge.noADSBTN.transform = CGAffineTransform(scaleX: 1.0, y: 1.0)
        }
    }
    
    func showMenu() {
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.0, execute: { [self] in
            self.gameViewControllerBridge.addChild(self.menuViewControllerBridge)
            self.gameViewControllerBridge.view.addSubview(self.menuViewControllerBridge.view)
            self.menuViewControllerBridge.view.frame = self.gameViewControllerBridge.view.bounds
            self.menuViewControllerBridge.view.alpha = 0
            //self.menuViewControllerBridge.view.center.y -= 15
            self.menuViewControllerBridge.view.transform = CGAffineTransform(scaleX: 0.9, y: 0.9)
            //zoomOutToActionCamera(zoomOutTo: 1.05, duration: 0.5)
            UIView.animate(withDuration: 0.5, delay: 0, options: .curveEaseOut) {
                self.menuViewControllerBridge.view.transform = CGAffineTransform(scaleX: 1.0, y: 1.0)
                self.menuViewControllerBridge.view.alpha  = 1
                //self.menuViewControllerBridge.view.center.y += 15
            }
        
            
        })
    }
    
    
    
    func gameOverAnimatonWindow(){
        DispatchQueue.main.asyncAfter(deadline: .now() + 1.5, execute: { [self] in
            UIView.animate(withDuration: 0.4, delay: 0.6, options: .curveEaseOut, animations: {
                gameOverViewControllerBridge.diagr.alpha = 1
                gameOverViewControllerBridge.lvlLable.alpha = 1
                
            }) { (completed) in
                calcRingExp()
            }
        })
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.5, execute: { [self] in
            gameViewControllerBridge.addChild(self.gameOverViewControllerBridge)
            gameViewControllerBridge.view.addSubview(self.gameOverViewControllerBridge.view)
            gameOverViewControllerBridge.view.frame = self.gameViewControllerBridge.view.bounds
            
            
            
            gameOverViewControllerBridge.view.transform = CGAffineTransform(scaleX: 0.70, y: 0.70)
            
            
            gameOverViewControllerBridge.view.center.y += 300
            gameOverViewControllerBridge.view.alpha = 0
            
            gameOverViewControllerBridge.diagr.alpha = 0
            gameOverViewControllerBridge.lvlLable.alpha = 0
            
            gameOverViewControllerBridge.gameOverLable.alpha = 1
            gameOverViewControllerBridge.newRecordLabel.alpha = 0
            gameOverViewControllerBridge.recordTextLabel.alpha = 0
            gameOverViewControllerBridge.bestScoreLabel.alpha = 0
            
            if coin == 0 {
                gameOverViewControllerBridge.gameOverCoinLabel.alpha = 0
                gameOverViewControllerBridge.gameOverCoinIcon.alpha = 0
            } else {
                gameOverViewControllerBridge.gameOverCoinLabel.alpha = 1
                gameOverViewControllerBridge.gameOverCoinIcon.alpha = 1
            }
            
//            gameOverViewControllerBridge.recordTextLabel.font = UIFont(name: "Ubuntu", size: 24)
//            gameOverViewControllerBridge.recordTextLabel.transform = CGAffineTransform(scaleX: 1.0, y: 1.0)
//            gameOverViewControllerBridge.bestScoreLabel.font = UIFont(name: "Ubuntu", size: 34)
//            gameOverViewControllerBridge.bestScoreLabel.transform = CGAffineTransform(scaleX: 1.0, y: 1.0)
            gameOverViewControllerBridge.gameOverScoreLaber.transform = CGAffineTransform(scaleX: 1.1, y: 1.1)
            
            
            UIView.animate(withDuration: 0.5, delay: 0, options: .curveEaseOut) {
                gameOverViewControllerBridge.view.transform = CGAffineTransform(scaleX: CGFloat(scaleInterface), y: CGFloat(scaleInterface))
                
                gameOverViewControllerBridge.view.center.y -= 300
                gameOverViewControllerBridge.gameOverScoreLaber.alpha = 1
                gameOverViewControllerBridge.view.alpha = 1
                mainScoreLabel.run(SKAction.fadeAlpha(to: 0, duration: 0.2))
                
            }
            UIView.animate(withDuration: 1.0 , delay: 2, options: .curveEaseOut) {
                gameOverViewControllerBridge.recordTextLabel.alpha = 0
                gameOverViewControllerBridge.bestScoreLabel.alpha = 0
                
            }
        })
    }
    
    
   
    //var diagr = SKSpriteNode()

    func calcRingExp() {
        DispatchQueue.main.asyncAfter(deadline: .now() + timeDurationRingAnimation, execute: { [self] in
//            if remainderIndex == 0 {
                let currentExp:Double = Double(birdExp)
                let percent:Double = currentExp / Double((lvlLader[birdLvl] / 100))
                timeDurationRingAnimation = Double((2.0 / 100) * percent)
                print("Получено опыта: \(currentExp)")
                print("Опыт в процентах: \(percent)")
                endIndex = startIndex + Int(percent)
                print("startIndex: \(startIndex)")
                print("endIndex: \(endIndex)")
                
                if endIndex >= 100 {
                    remainderIndex = Double(endIndex - 100)
                    endIndex = 100
                    print("remainder: \(remainderIndex)")
                    
                    animationRingExp(startIndex: startIndex, endIndex: endIndex, duration: timeDurationRingAnimation)
                }
                
                if endIndex < 100 {
                    animationRingExp(startIndex: startIndex, endIndex: endIndex, duration: timeDurationRingAnimation)
                }
//            }
//            else if remainderIndex != 0 {
//                let reminderIndexA = remainderIndex
//                remainderIndex = 0
//                timeDurationRingAnimation = Double((2.0 / 100) * reminderIndexA)
//                animationRingExp(startIndex: startIndex, endIndex: Int(reminderIndexA), duration: timeDurationRingAnimation)
//
//            }
        })
    }
    
    func animationRingExp(startIndex: Int, endIndex: Int, duration: TimeInterval) {
        for i in startIndex ... endIndex {
            imgListArray.add(UIImage(named: "\(i)diagr.png")!)
            //print("add: \(i)diagr.png")
        }
        //print("imgListArray \(imgListArray)")
        
        gameOverViewControllerBridge.diagr.animationImages = imgListArray as? [UIImage]
        gameOverViewControllerBridge.diagr.animationRepeatCount = 1
        gameOverViewControllerBridge.diagr.animationDuration = duration
        gameOverViewControllerBridge.diagr.startAnimating()
        
        UIView.animate(withDuration: 0.3, delay: 0, options: .curveEaseOut) {
            self.gameOverViewControllerBridge.diagr.transform = CGAffineTransform(scaleX: 1.1, y: 1.1)
        }
        UIView.animate(withDuration: 0.4, delay: 0.3, options: .curveEaseOut) {
            self.gameOverViewControllerBridge.diagr.transform = CGAffineTransform(scaleX: 1.0, y: 1.0)
        }
        DispatchQueue.main.asyncAfter(deadline: .now() + timeDurationRingAnimation, execute: { [self] in
            gameOverViewControllerBridge.diagr.image = (UIImage(named: "\(endIndex)diagr.png")!)
            
            //gameOverViewControllerBridge.diagr.stopAnimating()
            if endIndex == 100 {
                self.startIndex = 0
                
                birdLvl += 1
                gameOverViewControllerBridge.lvlLable.text = String(birdLvl)
                UIView.animate(withDuration: 0.5, delay: 0, options: .curveEaseOut) {
                    gameOverViewControllerBridge.lvlLable.transform = CGAffineTransform(scaleX: 2.0, y: 2.0)
                }
                UIView.animate(withDuration: 0.5, delay: 0.5, options: .curveEaseOut) {
                    gameOverViewControllerBridge.lvlLable.transform = CGAffineTransform(scaleX: 1.0, y: 1.0)
                }
                
                
            } else {
                self.startIndex = endIndex
            }
            
            
            if remainderIndex != 0 {
                birdExp = 0
                imgListArray.removeAllObjects()
//                let currentExp:Double = Double(birdExp)
//                let percent:Double = currentExp / Double((lvlLader[birdLvl] / 100))
                
                let recountPercent = lvlLader[birdLvl] / lvlLader[birdLvl - 1]
                remainderIndex /= Double(recountPercent)
                for i in 0 ... (Int(remainderIndex)) {
                    imgListArray.add(UIImage(named: "\(i)diagr.png")!)
                    print("add: \(i)diagr.png")
                }
                print("imgListArray2 \(imgListArray)")
                gameOverViewControllerBridge.diagr.animationImages = imgListArray as? [UIImage]
                gameOverViewControllerBridge.diagr.animationRepeatCount = 0
                gameOverViewControllerBridge.diagr.animationDuration = 0.6
                gameOverViewControllerBridge.diagr.startAnimating()
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.5, execute: { [self] in
                    gameOverViewControllerBridge.diagr.image = (UIImage(named: "\(Int(remainderIndex))diagr.png")!)
                    gameOverViewControllerBridge.diagr.stopAnimating()
                    remainderIndex = 0
                    self.startIndex = Int(remainderIndex)
                })
            }
            
        })
    }
    
    func gameOverNewRecordAnimatonWindow(){
        //Add gameOverViewController on scene
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 1.5, execute: { [self] in
            UIView.animate(withDuration: 0.4, delay: 0.6, options: .curveEaseOut, animations: {
                gameOverViewControllerBridge.diagr.alpha = 1
                gameOverViewControllerBridge.lvlLable.alpha = 1
                
            }) { (completed) in
                calcRingExp()
            }
        })
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.5, execute: { [self] in
            confettiFx()
        })
        
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.5, execute: { [self] in
            
            
            
            gameViewControllerBridge.addChild(gameOverViewControllerBridge)
            gameViewControllerBridge.view.addSubview(gameOverViewControllerBridge.view)
            gameOverViewControllerBridge.view.frame = gameViewControllerBridge.view.bounds
            
            //gameOverViewControllerBridge.diagr.image = UIImage(named:"3diagr.png")
            
            
            gameOverViewControllerBridge.view.transform = CGAffineTransform(scaleX: 0.70, y: 0.70)
            
            gameOverViewControllerBridge.diagr.alpha = 0
            gameOverViewControllerBridge.lvlLable.alpha = 0
            
            gameOverViewControllerBridge.view.center.y += 300
            gameOverViewControllerBridge.view.alpha = 0
            
            gameOverViewControllerBridge.gameOverLable.alpha = 0
            gameOverViewControllerBridge.newRecordLabel.alpha = 1
            gameOverViewControllerBridge.recordTextLabel.alpha = 0
            gameOverViewControllerBridge.bestScoreLabel.alpha = 0
            
            if coin == 0 {
                gameOverViewControllerBridge.gameOverCoinLabel.alpha = 0
                gameOverViewControllerBridge.gameOverCoinIcon.alpha = 0
            } else {
                gameOverViewControllerBridge.gameOverCoinLabel.alpha = 1
                gameOverViewControllerBridge.gameOverCoinIcon.alpha = 1
            }
//            gameOverViewControllerBridge.recordTextLabel.center.y = 205
//            gameOverViewControllerBridge.bestScoreLabel.center.y = 255

            gameOverViewControllerBridge.gameOverScoreLaber.transform = CGAffineTransform(scaleX: 1.0, y: 1.0)
            
            
            gameOverViewControllerBridge.gameOverScoreLaber.alpha = 1
            mainScoreLabel.run(SKAction.fadeAlpha(to: 0, duration: 0.2))
            //gameOverViewControllerBridge.recordTextLabel.text = "Рекорд"
            UIView.animate(withDuration: 0.5, delay: 0, options: .curveEaseOut, animations: {
                gameOverViewControllerBridge.view.transform = CGAffineTransform(scaleX: CGFloat(scaleInterface), y: CGFloat(scaleInterface))
                
                gameOverViewControllerBridge.view.center.y -= 300
                gameOverViewControllerBridge.view.alpha = 1
                
            }) { (completed) in
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.1, execute: { [] in
                    
                    UIView.animate(withDuration: 1.5, delay: 0, options: .curveEaseOut) {
                        gameOverViewControllerBridge.gameOverScoreLaber.transform = CGAffineTransform(scaleX: 1.5, y: 1.5)
                        gameOverViewControllerBridge.gameOverCoinIcon.center.y += 15
                        gameOverViewControllerBridge.gameOverCoinLabel.center.y += 15
                    }
                })
            }
        })
    }
    
    
//-------------------------------------- ANIMATION BACKGROUND ---------------------------------------
    func letsStarsMove() {
        //STARS
        stars = self.childNode(withName: "stars") as! SKSpriteNode
        stars2 = self.childNode(withName: "stars2") as! SKSpriteNode
        if moveBgStars == "yes" {
            stars.alpha = 0.0
            stars2.alpha = 0.0
            stars.position.y += CGFloat(speedStars)
            stars2.position.y += CGFloat(speedStars)


            if stars.position.y > ((self.scene?.size.height)! ) {
                stars.position.y = -(self.scene?.size.height)!
            }
            if stars2.position.y > ((self.scene?.size.height)! ) {
                stars2.position.y = -(self.scene?.size.height)!
            }
        }
    }
    
  
//------------------------- ANIMATION SIZE LABEL: "TAP TO START" --------------------------------------
    func tapToStartAnimation() {
        if tapToStartLabelAnimation != "full" {
            tapToStartLabel.run(SKAction.scale(to: 1, duration: 0.2))
            if tapToStartLabel.xScale >= 0.98 {
                tapToStartLabelAnimation = "full"
            }
        }
        
        if tapToStartLabelAnimation == "full" {
            tapToStartLabel.run(SKAction.scale(to: 0.8, duration: 0.2))
            if tapToStartLabel.xScale <= 0.81 {
                tapToStartLabelAnimation = "notFull"
            }
        }
    }
    
    
    
//                                          СКРЫТЬ ОБЪЕКТЫ
    func hideObjectsForStart() {
        self.tapToStartLabel.run(SKAction.fadeAlpha(to: 0, duration: 0.2))
    }


    
    
    
    
    
}
