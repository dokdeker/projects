import Foundation
import SpriteKit
extension GameScene {
    
    
    func interfaceDevices(){
        if UIDevice.current.userInterfaceIdiom == .phone {
            scaleInterface = 0.85
            zoomOutToActionCamera(zoomOutTo: 1.0, duration: 0)
            
            
        } else if UIDevice.current.userInterfaceIdiom == .pad {
            scaleInterface = 0.90
            zoomOutToActionCamera(zoomOutTo: 1.7, duration: 0)
            
            
        }
    }
    
    
    
}
