import Foundation
import SpriteKit

var amountActivatedBlocks = 0

extension GameScene {
    
    func didBegin(_ contact: SKPhysicsContact){
        let firstBody = contact.bodyA
        let secondBody = contact.bodyB
        
        
        
        if firstBody.categoryBitMask == birdCategory && secondBody.categoryBitMask == coinCategory || firstBody.categoryBitMask == coinCategory && secondBody.categoryBitMask == birdCategory {
            
            let coinNode = contact.bodyA.categoryBitMask == coinCategory ? contact.bodyA.node : contact.bodyB.node
            coinNode?.removeFromParent()
            addCoin()
            hapticTouchFx(force: .rigid)
            run(Sound.point)
            print("BIRD GET A GOOOOOOOLD")
        }
        
        
        
        if firstBody.categoryBitMask == detectBlockCategory && secondBody.categoryBitMask == blockCategory || firstBody.categoryBitMask == blockCategory && secondBody.categoryBitMask == detectBlockCategory {
            
            let detectedBlock = contact.bodyA.categoryBitMask == blockCategory ? contact.bodyA.node : contact.bodyB.node
            detectedBlock?.zPosition = 4
            detectedBlock?.physicsBody?.isDynamic = true
            detectedBlock?.physicsBody?.affectedByGravity = false
            detectedBlock?.physicsBody?.categoryBitMask = ghostCategory
            detectedBlock?.physicsBody?.velocity = CGVector(dx: 0, dy: (Int.random(in: 100 ... 300)))
            
            let randomRotationBlocks = ((Int.random(in: 1 ... 2)))
            if randomRotationBlocks == 1 {
                detectedBlock?.physicsBody?.applyAngularImpulse(CGFloat(1))
            } else {
                detectedBlock?.physicsBody?.applyAngularImpulse(CGFloat(-1))
            }
            
            //detectedBlock?.run(SKAction.fadeAlpha(to: 0.5, duration: 0.2))
            detectedBlock?.run(SKAction.colorize(with: SKColor(red: 223/255, green: 184/255, blue: 80/255, alpha: 1), colorBlendFactor: 0.8, duration: 0.2))
            detectedBlock?.run(SKAction.resize(toWidth: 100, height: 100, duration: 0.8))
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.2, execute: { [] in
                detectedBlock?.run(SKAction.fadeAlpha(to: 0, duration: 3.0))
                
                detectedBlock?.run(SKAction.scale(to: 0.3, duration: 0.3))
            })
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.8, execute: { [] in
                detectedBlock?.physicsBody?.velocity = CGVector(dx: 0, dy: (Int.random(in: 500 ... 900)))
                detectedBlock?.run(SKAction.scale(to: 0.2, duration: 0.3))
            })
            print("Our line found other blocks")
        }
        
        
        
        if firstBody.categoryBitMask == birdCategory && secondBody.categoryBitMask == accessibleBlockCategory || firstBody.categoryBitMask == accessibleBlockCategory && secondBody.categoryBitMask == birdCategory {
            
            let accessibleBlock1 = contact.bodyA.categoryBitMask == accessibleBlockCategory ? contact.bodyA.node : contact.bodyB.node
            accessibleBlock1?.physicsBody?.categoryBitMask = ghostCategory
            accessibleBlock1?.zPosition = 4
            accessibleBlock1?.physicsBody?.isDynamic = false
            accessibleBlock1?.physicsBody?.affectedByGravity = false
            accessibleBlock1?.physicsBody?.allowsRotation = false
            
            accessibleBlock1?.run(SKAction.fadeAlpha(to: 0, duration: 0.1))
            
            shakeCamera(layer: gameSceneCamera, ampX: 80, ampY: 48, numberOfShakes: 8, duration: 1)
            
            hapticTouchFx(force: .light)
            birdExp += exp 
            addScore()
            run(Sound.swooshing)
            //player(sound: Sound.swooshing!)
            print("BIRD collide with accessibleBlock")
        }
        
        
        
        if firstBody.categoryBitMask == birdCategory && secondBody.categoryBitMask == closedAccessibleBlockCategory || firstBody.categoryBitMask == closedAccessibleBlockCategory && secondBody.categoryBitMask == birdCategory {
            
            let closedAccessibleBlock = contact.bodyA.categoryBitMask == closedAccessibleBlockCategory ? contact.bodyA.node : contact.bodyB.node
            bird.physicsBody?.velocity = CGVector(dx: speedOfBirdX * 1.7, dy: 1560)
            bird.run(SKAction.rotate(toAngle: CGFloat(birdRotate), duration: 0.3))
            
            pinkBlockFX()
            //colorizeInAccessibleBlock(blockName: closedAccessibleBlock as! SKSpriteNode)
            
            scaleActionBlock(blockName: closedAccessibleBlock as! SKSpriteNode, scaleHight: 2.0, scaleLow: 1, scaleEnd: 1.6)
            
            shakeNode(layer: stars, ampX: 80, ampY: 48, numberOfShakes: 4, duration: 0.2)
            shakeNode(layer: stars2, ampX: 80, ampY: 48, numberOfShakes: 4, duration: 0.2)
            closedAccessibleBlock?.physicsBody?.categoryBitMask = accessibleBlockCategory
            
            
            print("BIRD collide with CLOSEDaccessibleBlock")
        }
        
        
        
        if firstBody.categoryBitMask == birdCategory && secondBody.categoryBitMask == closedLineBlockCategory || firstBody.categoryBitMask == closedLineBlockCategory && secondBody.categoryBitMask == birdCategory {
            
            let activatedBlock = contact.bodyA.categoryBitMask == closedLineBlockCategory ? contact.bodyA.node : contact.bodyB.node
            
            scaleActionBlock(blockName: activatedBlock as! SKSpriteNode, scaleHight: 2.4, scaleLow: 1.4, scaleEnd: 1.85)
            
            shakeNode(layer: stars, ampX: 80, ampY: 48, numberOfShakes: 4, duration: 0.2)
            shakeNode(layer: stars2, ampX: 80, ampY: 48, numberOfShakes: 4, duration: 0.2)
            
            
            
            if amountActivatedBlocks < 2 {
                bird.physicsBody?.velocity = CGVector(dx: speedOfBirdX * 1.1, dy: 1560)
                bird.run(SKAction.rotate(toAngle: CGFloat(birdRotate), duration: 0.3))
                colorizeInWrongBlock(blockName: activatedBlock as! SKSpriteNode)
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.1, execute: { [] in
                    activatedBlock?.physicsBody?.categoryBitMask = self.blockCategory
                    amountActivatedBlocks += 1
                    //print(amountActivatedBlocks)
                })
            } else {
                activatedBlock?.physicsBody?.categoryBitMask = accessibleBlockCategory
                activatedBlock?.physicsBody?.isDynamic = false
                activatedBlock?.physicsBody?.affectedByGravity = false
                //colorizeInAccessibleBlock(blockName: activatedBlock as! SKSpriteNode, indexThisGame: <#Int#>)
                activatedBlock?.run(SKAction.fadeAlpha(to: 0, duration: 0.1))
                //addScore()
                shakeCamera(layer: gameSceneCamera, ampX: 40, ampY: 24, numberOfShakes: 8, duration: 1)
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.1, execute: { [] in
                    amountActivatedBlocks = 0
                    //print("ОБНУЛИЛ!!!!!!!!!!\(amountActivatedBlocks)")
                })
            }
            
            print("BIRD collide with CLOSED LINE block")
        }
        
//        if firstBody.categoryBitMask == detectBlockClosedLineCategory && secondBody.categoryBitMask == closedLineBlockCategory || firstBody.categoryBitMask == closedLineBlockCategory && secondBody.categoryBitMask == detectBlockClosedLineCategory {
//
//            let detectedBlockClosedLine = contact.bodyA.categoryBitMask == closedLineBlockCategory ? contact.bodyA.node : contact.bodyB.node
//
//            detectedBlockClosedLine?.alpha = 0.3
//            print("detect bloct contact with closed line block")
//        }
        

        
        
        
        if firstBody.categoryBitMask == birdCategory && secondBody.categoryBitMask == blockCategory || firstBody.categoryBitMask == blockCategory && secondBody.categoryBitMask == birdCategory {
            
            let wrongBlockDetect = contact.bodyA.categoryBitMask == blockCategory ? contact.bodyA.node : contact.bodyB.node
            flyFeatherFx()
            zoomInOutActionCamera()
            shakeCamera(layer: gameSceneCamera, ampX: 400, ampY: 240, numberOfShakes: 8, duration: 1)
//            shakeNode(layer: stars, ampX: 160, ampY: 92, numberOfShakes: 8, duration: 0.4)
//            shakeNode(layer: stars2, ampX: 160, ampY: 92, numberOfShakes: 8, duration: 0.4)
            bangWrongBlockFx(positionFxY: bird.position.y - 50, positionFxX: (wrongBlockDetect?.position.x)!)
            
            wrongBlockDetect?.run(SKAction.scale(to: 0, duration: 0.3))
            wrongBlockDetect?.physicsBody?.categoryBitMask = ghostCategory
            wrongBlockDetect!.physicsBody?.isDynamic = true
            
            bird.physicsBody?.categoryBitMask = ghostCategory
            bird.physicsBody?.velocity = CGVector(dx: 0, dy: 2160)
            
//            enumerateChildNodes(withName: "speedFallFx") {
//                node, stop in
//                node.speed = 0
//            }
            
//            if let action = square.actionForKey("speedFallFx") {
//
//                    action.speed = 0
//            }
            hapticTouchFx(force: .heavy)
            funcGameOver()

            print("BIRD COLLIDED WITH WRONG BLOCK")
        }
        
        
        
//        if firstBody.categoryBitMask == detectBlockClosedLineCategory  && secondBody.categoryBitMask == blockCategory || firstBody.categoryBitMask == blockCategory && secondBody.categoryBitMask == detectBlockClosedLineCategory {
//
//            //let detectedCircleBlock = contact.bodyA.categoryBitMask == closedLineBlockCategory ? contact.bodyA.node : contact.bodyB.node
//            
//            
//            
//            print("VKVKVKVKVKVKVKVKVK")
//        }
        
        
//---------------------CIRCLE-----------------
        if firstBody.categoryBitMask == detectCircleCategory  && secondBody.categoryBitMask == blockCategory || firstBody.categoryBitMask == blockCategory && secondBody.categoryBitMask == detectCircleCategory {

            let detectedCircleBlock = contact.bodyA.categoryBitMask == blockCategory ? contact.bodyA.node : contact.bodyB.node
            
            detectedCircleBlock?.zPosition = 4
            detectedCircleBlock?.physicsBody?.isDynamic = true
            detectedCircleBlock?.physicsBody?.affectedByGravity = true
            detectedCircleBlock?.physicsBody?.allowsRotation = true
            detectedCircleBlock?.physicsBody?.categoryBitMask = ghostCategory
//            detectedCircleBlock?.physicsBody?.velocity = CGVector(dx: 0, dy: 800)
//            detectedCircleBlock?.run(SKAction.fadeAlpha(to: 0, duration: 1))
            print("our circle found wrong blocks ")
            if (detectedCircleBlock?.position.x)! > 0 {
                detectedCircleBlock?.physicsBody?.velocity = CGVector(dx: Int.random(in: 100...500), dy: Int.random(in: -80...2200))
                detectedCircleBlock?.run(SKAction.rotate(byAngle: CGFloat(Int.random(in: -8...8)), duration: 1))
                detectedCircleBlock?.run(SKAction.scale(to: CGFloat.random(in: 0.6...1.2), duration: 1))
            } else if (detectedCircleBlock?.position.x)! < 0 {
                detectedCircleBlock?.physicsBody?.velocity = CGVector(dx: Int.random(in: -500 ... -100), dy: Int.random(in: -80...2200))
                detectedCircleBlock?.run(SKAction.rotate(byAngle: CGFloat(Int.random(in: -8...8)), duration: 1))
                detectedCircleBlock?.run(SKAction.scale(to: CGFloat.random(in: 0.6...1.2), duration: 1))
            } else {
                detectedCircleBlock?.physicsBody?.velocity = CGVector(dx: 0, dy: -500)
                detectedCircleBlock?.run(SKAction.rotate(byAngle: CGFloat(Int.random(in: -8...8)), duration: 1))
            }
        }
        
        
        
        if firstBody.categoryBitMask == detectCircleCategory  && secondBody.categoryBitMask == accessibleBlockCategory || firstBody.categoryBitMask == accessibleBlockCategory && secondBody.categoryBitMask == detectCircleCategory {

            let detectedCircleBlock = contact.bodyA.categoryBitMask == accessibleBlockCategory ? contact.bodyA.node : contact.bodyB.node
            
            detectedCircleBlock?.zPosition = 4
            detectedCircleBlock?.physicsBody?.isDynamic = true
            detectedCircleBlock?.physicsBody?.affectedByGravity = true
            detectedCircleBlock?.physicsBody?.allowsRotation = true
            detectedCircleBlock?.physicsBody?.categoryBitMask = ghostCategory
//            detectedCircleBlock?.physicsBody?.velocity = CGVector(dx: 0, dy: 800)
//            detectedCircleBlock?.run(SKAction.fadeAlpha(to: 0, duration: 1))
            print("our circle found accessible blocks ")
            if (detectedCircleBlock?.position.x)! > 0 {
                detectedCircleBlock?.physicsBody?.velocity = CGVector(dx: Int.random(in: 100...500), dy: Int.random(in: -80...2200))
                detectedCircleBlock?.run(SKAction.rotate(byAngle: CGFloat(Int.random(in: -8...8)), duration: 1))
                detectedCircleBlock?.run(SKAction.scale(to: CGFloat.random(in: 0.6...1.2), duration: 1))
            } else if (detectedCircleBlock?.position.x)! < 0 {
                detectedCircleBlock?.physicsBody?.velocity = CGVector(dx: Int.random(in: -500 ... -100), dy: Int.random(in: -80...2200))
                detectedCircleBlock?.run(SKAction.rotate(byAngle: CGFloat(Int.random(in: -8...8)), duration: 1))
                detectedCircleBlock?.run(SKAction.scale(to: CGFloat.random(in: 0.6...1.2), duration: 1))
            } else {
                detectedCircleBlock?.physicsBody?.velocity = CGVector(dx: 0, dy: -500)
                detectedCircleBlock?.run(SKAction.rotate(byAngle: CGFloat(Int.random(in: -8...8)), duration: 1))
            }
        }
        
        
        
        if firstBody.categoryBitMask == detectCircleCategory  && secondBody.categoryBitMask == closedAccessibleBlockCategory || firstBody.categoryBitMask == closedAccessibleBlockCategory && secondBody.categoryBitMask == detectCircleCategory {

            let detectedCircleBlock = contact.bodyA.categoryBitMask == closedAccessibleBlockCategory ? contact.bodyA.node : contact.bodyB.node
            
            detectedCircleBlock?.zPosition = 4
            detectedCircleBlock?.physicsBody?.isDynamic = true
            detectedCircleBlock?.physicsBody?.affectedByGravity = true
            detectedCircleBlock?.physicsBody?.categoryBitMask = ghostCategory
            detectedCircleBlock?.physicsBody?.velocity = CGVector(dx: 0, dy: 800)
            detectedCircleBlock?.run(SKAction.fadeAlpha(to: 0, duration: 1))
            print("our circle found CLOSEaccessible blocks ")
        }
        
        
        
        if firstBody.categoryBitMask == detectCircleCategory  && secondBody.categoryBitMask == closedLineBlockCategory || firstBody.categoryBitMask == closedLineBlockCategory && secondBody.categoryBitMask == detectCircleCategory {

            let detectedCircleBlock = contact.bodyA.categoryBitMask == closedLineBlockCategory ? contact.bodyA.node : contact.bodyB.node
            
            detectedCircleBlock?.zPosition = 4
            detectedCircleBlock?.physicsBody?.isDynamic = true
            detectedCircleBlock?.physicsBody?.affectedByGravity = true
            detectedCircleBlock?.physicsBody?.categoryBitMask = ghostCategory
            detectedCircleBlock?.physicsBody?.velocity = CGVector(dx: 0, dy: 800)
            detectedCircleBlock?.run(SKAction.fadeAlpha(to: 0, duration: 1))
            print("our circle found CLOSED LINE blocks ")
        }
        
        
        
        if firstBody.categoryBitMask == detectCircleCategory  && secondBody.categoryBitMask == coinCategory || firstBody.categoryBitMask == coinCategory && secondBody.categoryBitMask == detectCircleCategory {

            let detectedCircleBlock = contact.bodyA.categoryBitMask == coinCategory ? contact.bodyA.node : contact.bodyB.node
            
            detectedCircleBlock?.zPosition = 4
            detectedCircleBlock?.physicsBody?.isDynamic = true
            detectedCircleBlock?.physicsBody?.affectedByGravity = true
            detectedCircleBlock?.physicsBody?.categoryBitMask = ghostCategory
            detectedCircleBlock?.physicsBody?.velocity = CGVector(dx: 0, dy: 800)
            detectedCircleBlock?.run(SKAction.fadeAlpha(to: 0, duration: 1))
            print("our circle found coin ")
        }
    }
    
    
}
