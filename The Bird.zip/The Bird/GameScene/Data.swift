import Foundation
import SpriteKit
extension GameScene {
    
    func saveData(){
        UserDefaults.standard.set(bestScore, forKey: "bestScoreDataKey")
        UserDefaults.standard.synchronize()
    }
    
    func loadData(){
        UserDefaults.standard.integer(forKey: "bestScoreDataKey")
        
    }
    
}
