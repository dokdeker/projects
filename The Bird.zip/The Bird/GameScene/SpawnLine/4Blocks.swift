import Foundation
import SpriteKit

extension GameScene {
    func spawnFourBlocks() {
        
        lineBlock = SKNode()
        lineBlock.name = "lineBlock"
        var firstRandomBlock = (Int.random(in: 2...3))
        var secondRandomBlock = (Int.random(in: 2...3))
        var thirdRandomBlock = (Int.random(in: 2...3))
        var forthRandomBlock = (Int.random(in: 2...3))
        var sumnuberBlocks = firstRandomBlock + secondRandomBlock + thirdRandomBlock + forthRandomBlock
        
        while sumnuberBlocks != 10 {
            firstRandomBlock = (Int.random(in: 2...3))
            secondRandomBlock = (Int.random(in: 2...3))
            thirdRandomBlock = (Int.random(in: 2...3))
            forthRandomBlock = (Int.random(in: 2...3))
            sumnuberBlocks = firstRandomBlock + secondRandomBlock + thirdRandomBlock + forthRandomBlock
        }
        
        let block1 = SKSpriteNode(imageNamed: "block1х\(firstRandomBlock)")
        createStandartBlock(blockName: block1, scale: 1.6)
        
        let block2 = SKSpriteNode(imageNamed: "block1х\(secondRandomBlock)")
        createStandartBlock(blockName: block2, scale: 1.6)
        
        let block3 = SKSpriteNode(imageNamed: "block1х\(thirdRandomBlock)")
        createStandartBlock(blockName: block3, scale: 1.6)
        
        let block4 = SKSpriteNode(imageNamed: "block1х\(forthRandomBlock)")
        createStandartBlock(blockName: block4, scale: 1.6)
        
        
        
        
        
        
        
       //POSITION
        let allWeightBlock = (block1.size.width + block2.size.width + block3.size.width + block4.size.width) + 146
        let pointStartForBlock = (1080 - allWeightBlock)/2
        let firstPositionBlockX = (pointStartForBlock - 540) + ((block1.size.width / 2))
        
        block1.position = CGPoint(x: firstPositionBlockX, y: -1300)
        block2.position = CGPoint(x: block1.position.x + (block1.size.width / 2) + ((block2.size.width / 2) + 48), y: -1300)
        block3.position = CGPoint(x: (block2.position.x + (block2.size.width / 2)) + ((block3.size.width / 2) + 48), y: -1300)
        block4.position = CGPoint(x: (block3.position.x + (block3.size.width / 2)) + ((block4.size.width / 2) + 48), y: -1300)
       
        
        
//------------------------------COLORIZE BLOCK AND CHANGE CATEGORY
        let willClosedBlock = (Int.random(in: 1 ... 100))
        if willClosedBlock <= -1 {
            createClosedAccessibleBlock4(firstElement: block1, secondElement: block2, thirdElement: block3, fourthElement: block4)
        } else {
            createAccessibleBlock4(firstElement: block1, secondElement: block2, thirdElement: block3, fourthElement: block4)
        }
        
        
// ACCESSIBLE BLOCK

// ACCESSIBLE BLOCK [END]
        
//-----------------------[END] COLORIZE BLOCK AND CHANGE CATEGORY [END]
        
        
        lineBlock.addChild(block1)
        lineBlock.addChild(block2)
        lineBlock.addChild(block3)
        lineBlock.addChild(block4)

        lineBlock.run(moveAndRemove)
        self.addChild(lineBlock)
    
    }
}
