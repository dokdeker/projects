import Foundation
import SpriteKit

var lastNumberAccessBlock = (Int.random(in: 1...3))

extension GameScene {
    func createStandartBlock(blockName: SKSpriteNode, scale: CGFloat ) {
        blockName.zPosition = 6
        blockName.setScale(scale)
        blockName.size.height = 110
        blockName.physicsBody = SKPhysicsBody()
        blockName.physicsBody = SKPhysicsBody(rectangleOf: blockName.size)
        blockName.physicsBody?.categoryBitMask = blockCategory
        blockName.physicsBody?.collisionBitMask = birdCategory
        blockName.physicsBody?.contactTestBitMask = birdCategory
        blockName.physicsBody?.isDynamic = false
        blockName.physicsBody?.affectedByGravity = false
        if gameStatus == "playing" {
            blockName.run(SKAction.colorize(with: SKColor(red: 208/255, green: 119/255, blue: 197/255, alpha: 1), colorBlendFactor: 0.3, duration: 0))
        }
    }
    
    
    
    func createAccessibleBlock4(firstElement: SKSpriteNode, secondElement: SKSpriteNode, thirdElement: SKSpriteNode, fourthElement: SKSpriteNode) {
//        var accessibleBlock = (Int.random(in: 1 ... 4))
//        while lastNumberAccessBlock == accessibleBlock {
//            accessibleBlock = (Int.random(in: 1 ... 4))
//        }
//        lastNumberAccessBlock = accessibleBlock
//
        
        var accessibleBlock = 0
        
        if lastNumberAccessBlock == 4 {
            let randomBlock = (Int.random(in: 1 ... 2))
            accessibleBlock = randomBlock
        }
        if lastNumberAccessBlock == 3 {
            let randomBlock = (Int.random(in: 1 ... 2))
            accessibleBlock = randomBlock
        }
        if lastNumberAccessBlock == 2 {
            let randomBlock = (Int.random(in: 3 ... 4))
            accessibleBlock = randomBlock
        }
        if lastNumberAccessBlock == 1 {
            let randomBlock = (Int.random(in: 3 ... 4))
            accessibleBlock = randomBlock
        }
        
        lastNumberAccessBlock = accessibleBlock
        
        
        
        //DispatchQueue.main.asyncAfter(deadline: .now() + 3.5, execute: { [self] in
        DispatchQueue.main.asyncAfter(deadline: .now() + DispatchTimeInterval.milliseconds(Int(timeDelaySpawnBlock * 1000)), execute: { [self] in
            
            if gameStatus == "playing"{
                if accessibleBlock == 1  {
                    firstElement.physicsBody?.categoryBitMask = accessibleBlockCategory
                    colorizeInAccessibleBlock(blockName: firstElement)
                    scaleActionBlock(blockName: firstElement, scaleHight: 2.0, scaleLow: 1.0, scaleEnd: 1.6)
                    showAccessBlockFX(positionX: firstElement.position.x, positionY: firstElement.position.y)

                } else if accessibleBlock == 2 {
                    secondElement.physicsBody?.categoryBitMask = accessibleBlockCategory
                    colorizeInAccessibleBlock(blockName: secondElement)
                    scaleActionBlock(blockName: secondElement, scaleHight: 2.0, scaleLow: 1.0, scaleEnd: 1.6)
                    showAccessBlockFX(positionX: secondElement.position.x, positionY: secondElement.position.y)

                } else if accessibleBlock == 3 {
                    thirdElement.physicsBody?.categoryBitMask = accessibleBlockCategory
                    colorizeInAccessibleBlock(blockName: thirdElement)
                    scaleActionBlock(blockName: thirdElement, scaleHight: 2.0, scaleLow: 1.0, scaleEnd: 1.6)
                    showAccessBlockFX(positionX: thirdElement.position.x, positionY: thirdElement.position.y)
                } else if accessibleBlock == 4 {
                    fourthElement.physicsBody?.categoryBitMask = accessibleBlockCategory
                    colorizeInAccessibleBlock(blockName: fourthElement)
                    scaleActionBlock(blockName: fourthElement, scaleHight: 2.0, scaleLow: 1.0, scaleEnd: 1.6)
                    showAccessBlockFX(positionX: fourthElement.position.x, positionY: fourthElement.position.y)
                }
            }
        })
    }

    
    
    func createClosedAccessibleBlock4(firstElement: SKSpriteNode, secondElement: SKSpriteNode, thirdElement: SKSpriteNode, fourthElement: SKSpriteNode) {
        var closedAccessibleBlock = (Int.random(in: 2 ... 3))
        
        while lastNumberAccessBlock == closedAccessibleBlock {
            closedAccessibleBlock = (Int.random(in: 2 ... 3))
        }
        lastNumberAccessBlock = closedAccessibleBlock
        
        //DispatchQueue.main.asyncAfter(deadline: .now() + 3.5, execute: { [self] in
        DispatchQueue.main.asyncAfter(deadline: .now() + DispatchTimeInterval.milliseconds(Int(timeDelaySpawnBlock * 1000)), execute: { [self] in
            if gameStatus == "playing"  {
                if closedAccessibleBlock == 1  {
                    firstElement.physicsBody?.categoryBitMask = closedAccessibleBlockCategory
                    colorizeInClosedAccessibleBlock(blockName: firstElement)
                    scaleActionBlock(blockName: firstElement, scaleHight: 2.0, scaleLow: 1.0, scaleEnd: 1.6)
                    showAccessBlockFX(positionX: firstElement.position.x, positionY: firstElement.position.y)
                    
                } else if closedAccessibleBlock == 2 {
                    secondElement.physicsBody?.categoryBitMask = closedAccessibleBlockCategory
                    colorizeInClosedAccessibleBlock(blockName: secondElement)
                    scaleActionBlock(blockName: secondElement, scaleHight: 2.0, scaleLow: 1.0, scaleEnd: 1.6)
                    showAccessBlockFX(positionX: secondElement.position.x, positionY: secondElement.position.y)
                } else if closedAccessibleBlock == 3 {
                    thirdElement.physicsBody?.categoryBitMask = closedAccessibleBlockCategory
                    colorizeInClosedAccessibleBlock(blockName: thirdElement)
                    scaleActionBlock(blockName: thirdElement, scaleHight: 2.0, scaleLow: 1.0, scaleEnd: 1.6)
                    showAccessBlockFX(positionX: thirdElement.position.x, positionY: thirdElement.position.y)
                } else if closedAccessibleBlock == 4 {
                    fourthElement.physicsBody?.categoryBitMask = closedAccessibleBlockCategory
                    colorizeInClosedAccessibleBlock(blockName: fourthElement)
                    scaleActionBlock(blockName: fourthElement, scaleHight: 2.0, scaleLow: 1.0, scaleEnd: 1.6)
                    showAccessBlockFX(positionX: fourthElement.position.x, positionY: fourthElement.position.y)
                }
            }
        })
    }
    
    
    
    func createAccessibleBlock3(firstElement: SKSpriteNode, secondElement: SKSpriteNode, thirdElement: SKSpriteNode) {
//        var accessibleBlock = (Int.random(in: 1 ... 3))
//        while lastNumberAccessBlock == accessibleBlock {
//            accessibleBlock = (Int.random(in: 1 ... 3))
//        }
//
//        lastNumberAccessBlock = accessibleBlock
        var accessibleBlock = 0
        if lastNumberAccessBlock == 4 {
            let randomBlock = (Int.random(in: 1 ... 2))
            accessibleBlock = randomBlock
        }
        
        if lastNumberAccessBlock == 3 {
            let randomBlock = (Int.random(in: 1 ... 2))
            accessibleBlock = randomBlock
        }
        if lastNumberAccessBlock == 2 {
            let randomBlock = (Int.random(in: 2 ... 3))
            accessibleBlock = randomBlock
        }
        if lastNumberAccessBlock == 1 {
            let randomBlock = (Int.random(in: 2 ... 3))
            accessibleBlock = randomBlock
        }
        lastNumberAccessBlock = accessibleBlock
       
        //DispatchQueue.main.asyncAfter(deadline: .now() + 3.5, execute: { [self] in
        DispatchQueue.main.asyncAfter(deadline: .now() + DispatchTimeInterval.milliseconds(Int(timeDelaySpawnBlock * 1000)), execute: { [self] in
            
            if gameStatus == "playing"{
                if accessibleBlock == 1  {
                    firstElement.physicsBody?.categoryBitMask = accessibleBlockCategory
                    colorizeInAccessibleBlock(blockName: firstElement)
                    scaleActionBlock(blockName: firstElement, scaleHight: 2.4, scaleLow: 1.4, scaleEnd: 1.85)
                    showAccessBlockFX(positionX: firstElement.position.x, positionY: firstElement.position.y)

                } else if accessibleBlock == 2 {
                    secondElement.physicsBody?.categoryBitMask = accessibleBlockCategory
                    colorizeInAccessibleBlock(blockName: secondElement)
                    scaleActionBlock(blockName: secondElement, scaleHight: 2.4, scaleLow: 1.4, scaleEnd: 1.85)
                    showAccessBlockFX(positionX: secondElement.position.x, positionY: secondElement.position.y)

                } else if accessibleBlock == 3 {
                    thirdElement.physicsBody?.categoryBitMask = accessibleBlockCategory
                    colorizeInAccessibleBlock(blockName: thirdElement)
                    scaleActionBlock(blockName: thirdElement, scaleHight: 2.4, scaleLow: 1.4, scaleEnd: 1.85)
                    showAccessBlockFX(positionX: thirdElement.position.x, positionY: thirdElement.position.y)
                }
            }

        })
    }
    
    
    
    func createClosedAccessibleBlock3(firstElement: SKSpriteNode, secondElement: SKSpriteNode, thirdElement: SKSpriteNode) {
        var closedAccessibleBlock = (Int.random(in: 1 ... 3))
        
        while lastNumberAccessBlock == closedAccessibleBlock {
            closedAccessibleBlock = (Int.random(in: 1 ... 3))
        }
        lastNumberAccessBlock = closedAccessibleBlock
        
        //DispatchQueue.main.asyncAfter(deadline: .now() + 3.5, execute: { [self] in
        
        DispatchQueue.main.asyncAfter(deadline: .now() + DispatchTimeInterval.milliseconds(Int(timeDelaySpawnBlock * 1000)), execute: { [self] in
            //let indexGameSt = indexGame
            if gameStatus == "playing" {
                if closedAccessibleBlock == 1  {
                    firstElement.physicsBody?.categoryBitMask = closedAccessibleBlockCategory
                    colorizeInClosedAccessibleBlock(blockName: firstElement)
                    scaleActionBlock(blockName: firstElement, scaleHight: 2.4, scaleLow: 1.4, scaleEnd: 1.85)
                    showAccessBlockFX(positionX: firstElement.position.x, positionY: firstElement.position.y)
                    
                } else if closedAccessibleBlock == 2 {
                    secondElement.physicsBody?.categoryBitMask = closedAccessibleBlockCategory
                    colorizeInClosedAccessibleBlock(blockName: secondElement)
                    scaleActionBlock(blockName: firstElement, scaleHight: 2.4, scaleLow: 1.4, scaleEnd: 1.85)
                    showAccessBlockFX(positionX: secondElement.position.x, positionY: secondElement.position.y)
                } else if closedAccessibleBlock == 3 {
                    thirdElement.physicsBody?.categoryBitMask = closedAccessibleBlockCategory
                    colorizeInClosedAccessibleBlock(blockName: thirdElement)
                    scaleActionBlock(blockName: firstElement, scaleHight: 2.4, scaleLow: 1.4, scaleEnd: 1.85)
                    showAccessBlockFX(positionX: thirdElement.position.x, positionY: thirdElement.position.y)
                }
            }
        })
    }
    
    
    
    func createClosedLine3(firstElement: SKSpriteNode, secondElement: SKSpriteNode, thirdElement: SKSpriteNode) {
        
        //DispatchQueue.main.asyncAfter(deadline: .now() + 3.5, execute: { [self] in
        DispatchQueue.main.asyncAfter(deadline: .now() + DispatchTimeInterval.milliseconds(Int(timeDelaySpawnBlock * 1000)), execute: { [self] in
            if gameStatus == "playing"  {
                colorizeLinePinkFx(positionX: 0, positionY: thirdElement.position.y)
                
                firstElement.physicsBody?.categoryBitMask = closedLineBlockCategory
                scaleActionBlock(blockName: firstElement, scaleHight: 2.4, scaleLow: 1.4, scaleEnd: 1.85)
                colorizeInClosedAccessibleBlock(blockName: firstElement)
                
                secondElement.physicsBody?.categoryBitMask = closedLineBlockCategory
                scaleActionBlock(blockName: secondElement, scaleHight: 2.4, scaleLow: 1.4, scaleEnd: 1.85)
                colorizeInClosedAccessibleBlock(blockName: secondElement)
                
                thirdElement.physicsBody?.categoryBitMask = closedLineBlockCategory
                colorizeInClosedAccessibleBlock(blockName: thirdElement)
                scaleActionBlock(blockName: thirdElement, scaleHight: 2.4, scaleLow: 1.4, scaleEnd: 1.85)
            }
        })
    }
    
    
    
    func createDetectBlock() {
        detectBlock.zPosition = 4
        detectBlock.alpha = 0
        detectBlock.position.y = 1600
        detectBlock.position.x = 0
        detectBlock.physicsBody = SKPhysicsBody()
        detectBlock.physicsBody = SKPhysicsBody(rectangleOf: detectBlock.size)
        detectBlock.physicsBody?.categoryBitMask = detectBlockCategory
        detectBlock.physicsBody?.collisionBitMask = blockCategory
        detectBlock.physicsBody?.contactTestBitMask = blockCategory
        detectBlock.physicsBody?.affectedByGravity = false
        detectBlock.physicsBody?.isDynamic = true
        addChild(detectBlock)
    }
    
    
    
    func createDetectCircle() {
        detectCircle = self.childNode(withName: "detectCircle") as! SKSpriteNode
        detectCircle.alpha = 0
        detectCircle.zPosition = 4
        detectCircle.position.y = 960
        detectCircle.position.x = 0
        
        detectCircle.physicsBody = SKPhysicsBody()
        detectCircle.physicsBody = SKPhysicsBody(circleOfRadius: detectCircle.size.width / 2)
        detectCircle.physicsBody?.categoryBitMask = detectCircleCategory
        detectCircle.physicsBody?.collisionBitMask = blockCategory | accessibleBlockCategory | coinCategory | closedAccessibleBlockCategory | closedLineBlockCategory
        detectCircle.physicsBody?.contactTestBitMask = blockCategory | accessibleBlockCategory | coinCategory | closedAccessibleBlockCategory | closedLineBlockCategory
        detectCircle.physicsBody?.affectedByGravity = false
        detectCircle.physicsBody?.isDynamic = false
        detectCircle.physicsBody?.allowsRotation = false
    }
    
    
    
}

