import Foundation
import SpriteKit

var firstLineHasBlocks = 3

extension GameScene {
    
    func spawnLineBlocks() {

        if firstLineHasBlocks == 3 {
            spawnThreeBlocks()
            lastLineBlockWas = 3
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.5, execute: { [] in
                firstLineHasBlocks = 0
            })
            
            
        }
        
        if firstLineHasBlocks == 0 && spawnTrackCoinStatus == "not active" {
            let chanceSpawnElementOnLine = (Int.random(in: 1...100))
            
            let chanceSpawnFourBlocks = 70
            let chanceSpawnThreeBlocks = 30
            let chanceSpawnCoinTrack = 4
            
            if chanceSpawnElementOnLine <= chanceSpawnCoinTrack && score >= 10 && gameStatus == "playing"  {
                createCoinTrack()
                
                
            } else if chanceSpawnElementOnLine <= chanceSpawnThreeBlocks && lastLineBlockWas != 3 {
                spawnThreeBlocks()
                lastLineBlockWas = 3
                
            } else if chanceSpawnElementOnLine <= chanceSpawnFourBlocks  {
                spawnFourBlocks()
                lastLineBlockWas = 4
                
            } else {
                spawnFourBlocks()
                lastLineBlockWas = 4
            }

        }


        
//-----------------------COIN------------
        
        let distanceInOneSec = Double(moveByLine) / moveLineSpeed
        let distanceInDelaySpawn = ((distanceInOneSec * timeDelaySpawnLine) / 100) * 87
        // 87 потому что минус 13% потому что скорость 1.13
        let distanceInSpeed = distanceInDelaySpawn * Double(coefficientSpeedNode)
        let centerPosition = distanceInSpeed / 2
        let centerPostionAfterSpawnLine = -1310 - centerPosition
        
        
            
        let chanceSpawnCoin = (Int.random(in: 1...100))
        
        if chanceSpawnCoin <= 1 &&  lastAmountCoin != 4 && score >= 10 && spawnTrackCoinStatus == "not active"  {
            createCoin(positionX: -375, positionY: CGFloat(centerPostionAfterSpawnLine), delaySpawn: 0)
            createCoin(positionX: -125, positionY: CGFloat(centerPostionAfterSpawnLine), delaySpawn: 0)
            createCoin(positionX: 125, positionY: CGFloat(centerPostionAfterSpawnLine), delaySpawn: 0)
            createCoin(positionX: 375, positionY: CGFloat(centerPostionAfterSpawnLine), delaySpawn: 0)
            lastAmountCoin = 4
            
        } else if chanceSpawnCoin <= 2 &&  lastAmountCoin != 3 && spawnTrackCoinStatus == "not active"  {
            createCoin(positionX: -300, positionY: CGFloat(centerPostionAfterSpawnLine), delaySpawn: 0)
            createCoin(positionX: 0, positionY: CGFloat(centerPostionAfterSpawnLine), delaySpawn: 0)
            createCoin(positionX: 300, positionY: CGFloat(centerPostionAfterSpawnLine), delaySpawn: 0)
            lastAmountCoin = 3
            
        } else if chanceSpawnCoin <= 3 &&  lastAmountCoin != 2 && spawnTrackCoinStatus == "not active" {
            createCoin(positionX: -250, positionY: CGFloat(centerPostionAfterSpawnLine), delaySpawn: 0)
            createCoin(positionX: 250, positionY: CGFloat(centerPostionAfterSpawnLine), delaySpawn: 0)
            lastAmountCoin = 2
            
        } else if chanceSpawnCoin <= 60 &&  lastAmountCoin != 1 && spawnTrackCoinStatus == "not active" {
            createCoin(positionX: CGFloat(Int.random(in: -320 ..< 320)), positionY: CGFloat(centerPostionAfterSpawnLine), delaySpawn: 0)
            lastAmountCoin = 1
            
        } else {
            lastAmountCoin = 0
        }
        
        
        
        
    }
    
    
    
    func changeSpeedNode(fromScore: Int, speed:CGFloat, delaySpawn:CGFloat) {
        if gameStatus != "playing" {
            enumerateChildNodes(withName: "BgBlock", using: ({
                (node, error) in
                node.speed = 0.5
            }))
        }
        if score >= fromScore /*&& score < toScore*/ && gameStatus == "playing"{
            coefficientSpeedNode = speed
            timeDelaySpawnBlock = delaySpawn
            
            //timeDelaySpawnLine = 2.0
            
            enumerateChildNodes(withName: "speedFallFx", using:  ({
                (node, error) in
                //node.speed = speed / 4
            }))
            
            
            
            speedCoinAnimation = 0.025 * speed
            
            
            let startVar:CGFloat = (1250/8)
            yPositionFx = ((startVar) * delaySpawn) * 2
            speedStars = 0.8 * Double(coefficientSpeedNode)
            enumerateChildNodes(withName: "lineBlock", using: ({
                (node, error) in
                node.speed = speed
            }))
            
            enumerateChildNodes(withName: "BgBlock", using: ({
                (node, error) in
                node.speed = speed
            }))
            
            enumerateChildNodes(withName: "coin", using: ({
                (node, error) in
                node.speed = speed
            }))
        }
    }
    
    func speedLine() {
        changeSpeedNode(fromScore: 0, speed: 1.33, delaySpawn: 1.5)
        changeSpeedNode(fromScore: 3, speed: 1.36, delaySpawn: 1.5)
        changeSpeedNode(fromScore: 6, speed: 1.39, delaySpawn: 1.5)
        changeSpeedNode(fromScore: 9, speed: 1.42, delaySpawn: 1.5)
        changeSpeedNode(fromScore: 12, speed: 1.45, delaySpawn: 1.5)
        changeSpeedNode(fromScore: 15, speed: 1.48, delaySpawn: 1.5)
        changeSpeedNode(fromScore: 18, speed: 1.51, delaySpawn: 1.5)
        changeSpeedNode(fromScore: 21, speed: 1.54, delaySpawn: 1.5)
        changeSpeedNode(fromScore: 24, speed: 1.57, delaySpawn: 1.0)
        changeSpeedNode(fromScore: 27, speed: 1.60, delaySpawn: 1.0)
        changeSpeedNode(fromScore: 30, speed: 1.63, delaySpawn: 1.0)
        changeSpeedNode(fromScore: 33, speed: 1.66, delaySpawn: 1.0)
        changeSpeedNode(fromScore: 36, speed: 1.69, delaySpawn: 0.5)
        changeSpeedNode(fromScore: 39, speed: 1.72, delaySpawn: 0.5)
        changeSpeedNode(fromScore: 42, speed: 1.75, delaySpawn: 0.5)
        changeSpeedNode(fromScore: 45, speed: 1.78, delaySpawn: 0.5)
        changeSpeedNode(fromScore: 48, speed: 1.81, delaySpawn: 0.0)
        changeSpeedNode(fromScore: 51, speed: 1.84, delaySpawn: 0.0)
        changeSpeedNode(fromScore: 54, speed: 1.87, delaySpawn: 0.0)
        changeSpeedNode(fromScore: 59, speed: 1.90, delaySpawn: 0.0)
        changeSpeedNode(fromScore: 62, speed: 1.93, delaySpawn: 0.0)
        changeSpeedNode(fromScore: 65, speed: 1.96, delaySpawn: 0.0)
        changeSpeedNode(fromScore: 68, speed: 1.99, delaySpawn: 0.0)
        changeSpeedNode(fromScore: 71, speed: 2.02, delaySpawn: 0.0)
        changeSpeedNode(fromScore: 74, speed: 2.05, delaySpawn: 0.0)
        changeSpeedNode(fromScore: 77, speed: 2.08, delaySpawn: 0.0)
        changeSpeedNode(fromScore: 80, speed: 2.11, delaySpawn: 0.0)
        changeSpeedNode(fromScore: 83, speed: 2.14, delaySpawn: 0.0)
        changeSpeedNode(fromScore: 86, speed: 2.17, delaySpawn: 0.0)
        changeSpeedNode(fromScore: 89, speed: 2.20, delaySpawn: 0.0)
        changeSpeedNode(fromScore: 92, speed: 2.23, delaySpawn: 0.0)
        changeSpeedNode(fromScore: 95, speed: 2.26, delaySpawn: 0.0)
        changeSpeedNode(fromScore: 98, speed: 2.29, delaySpawn: 0.0)
        changeSpeedNode(fromScore: 101, speed: 2.30, delaySpawn: 0.0)
    }
    
    
    
    
    
    
    
    
    
    
    
}
    
    
    
    
    

