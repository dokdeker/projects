 import Foundation
 import SpriteKit

 extension GameScene {
    func spawnThreeBlocks() {
        lineBlock = SKNode()
        lineBlock.name = "lineBlock"
        let firstRandomBlock = 3
        let secondRandomBlock = 3
        let thirdRandomBlock = 3
        
        //let detectBlockClosedLine = SKSpriteNode(color: .red, size: CGSize(width: 1080, height: 20))
        //detectBlockClosedLine.alpha = 1
        //detectBlockClosedLine.zPosition = 13
        
//        detectBlockClosedLine.physicsBody = SKPhysicsBody()
//
//        detectBlockClosedLine.physicsBody = SKPhysicsBody(rectangleOf: detectBlockClosedLine.size)
//        detectBlockClosedLine.physicsBody?.categoryBitMask = detectBlockClosedLineCategory
//        detectBlockClosedLine.physicsBody?.collisionBitMask = closedLineBlockCategory | blockCategory
//        detectBlockClosedLine.physicsBody?.contactTestBitMask = closedLineBlockCategory | blockCategory
//        detectBlockClosedLine.physicsBody?.isDynamic = false
//        detectBlockClosedLine.physicsBody?.affectedByGravity = false
//        detectBlockClosedLine.position.y = -1300
        
        let block1 = SKSpriteNode(imageNamed: "block1х\(firstRandomBlock)")
        createStandartBlock(blockName: block1, scale: 1.85)
        
        let block2 = SKSpriteNode(imageNamed: "block1х\(secondRandomBlock)")
        createStandartBlock(blockName: block2, scale: 1.85)
        
        let block3 = SKSpriteNode(imageNamed: "block1х\(thirdRandomBlock)")
        createStandartBlock(blockName: block3, scale: 1.85)

        
        
        
        
        
        
       //POSITION
        let allWeightBlock = (block1.size.width + block2.size.width + block3.size.width ) + 88
        let pointStartForBlock = (1080 - allWeightBlock)/2
        let firstPositionBlockX = (pointStartForBlock - 540) + ((block1.size.width / 2))
        
        block1.position = CGPoint(x: firstPositionBlockX, y: -1300)
        block2.position = CGPoint(x: block1.position.x + (block1.size.width / 2) + ((block2.size.width / 2) + 44), y: -1300)
        block3.position = CGPoint(x: (block2.position.x + (block2.size.width / 2)) + ((block3.size.width / 2) + 44), y: -1300)
        
        
        
//------------------------------COLORIZE BLOCK AND CHANGE CATEGORY

        
        
        
        
        
//        let willClosedLine = (Int.random(in: 1 ... 100))
//        if willClosedLine <= 10 {
//            createClosedLine3(firstElement: block1, secondElement: block2, thirdElement: block3)
//        } else {
//            createAccessibleBlock3(firstElement: block1, secondElement: block2, thirdElement: block3)
//        }
        
        

        
        let willClosedBlock = (Int.random(in: 1 ... 100))
        if willClosedBlock <= -1 {
            createClosedAccessibleBlock3(firstElement: block1, secondElement: block2, thirdElement: block3)
        } else {
            createAccessibleBlock3(firstElement: block1, secondElement: block2, thirdElement: block3)
        }
//-----------------------------COLORIZE BLOCK AND CHANGE CATEGORY END
//        

 
        lineBlock.addChild(block1)
        lineBlock.addChild(block2)
        lineBlock.addChild(block3)
       // lineBlock.addChild(detectBlockClosedLine)
        
        //addChild(detectBlockClosedLine)
        
        //detectBlockClosedLine.run(moveAndRemove)
        //detectBlockClosedLine.run(upAndDown)
        lineBlock.run(moveAndRemove)
        self.addChild(lineBlock)
    }
 }
