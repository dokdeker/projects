import Foundation
import SpriteKit

extension GameScene {
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
    
    }
   
    
    
    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?){
        for touch in touches {
                
            let location = touch.location(in: self)
            if gameStatus != "Game over"   {
                if bg.contains(location) {
                    if gameStatus == "wait" {
                        gameStatus = "playing"
                        
                        //speedStars = 2.0
                        

                        let spawnLine = SKAction.run({
                                    () in
                            self.spawnLineBlocks()
                            //self.spawnBgBlocks()
                        })
                        
                        let pauseAfterSpawnLine = SKAction.wait(forDuration: timeDelaySpawnLine)
                        let SequenceSpawnAndPause = SKAction.sequence([spawnLine, pauseAfterSpawnLine])
                        let Sequence_repitForever = SKAction.repeatForever(SequenceSpawnAndPause)
                        self.run(Sequence_repitForever)
                                
                                
                        //let distance = CGFloat(self.frame.height + wallPair.frame.width)
                        let moveLine = SKAction.moveBy(x: 0, y: moveByLine, duration: TimeInterval(moveLineSpeed))
                        let removeLine = SKAction.removeFromParent()
                        moveAndRemove = SKAction.sequence([moveLine, removeLine])
                        
                        let upBlock = SKAction.moveBy(x: 0, y: 380, duration: TimeInterval(0.2))
                        let downBlock = SKAction.moveBy(x: 0, y: -320, duration: TimeInterval(0.05))
                        let seqRepFor = SKAction.sequence([upBlock, downBlock])
                        upAndDown = SKAction.repeatForever(seqRepFor)
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        

                    }
                }
            }
                
            

            
            
                if bg.contains(location) && gameStatus == "playing"{
                    flyBird(velcityX: speedOfBirdX, velcityY: speedOfBirdY)
                    run(Sound.wing)
                    //player(sound: Sound.wing!)
                }
        }
    }
    

    
    
    
    
    
    
    
    
    
}
