//
//  GameScene.swift
//  The Bird
//
//  Created by Evgeniy T on 30.04.2020.
//  Copyright © 2020 Evgeniy T. All rights reserved.
//

import SpriteKit
import GameplayKit

class GameScene: SKScene {
    
    
    //var i = Float()
    
    //texture
    var bgTexture: SKTexture!
    
    //Sprites Nodes
    var bg = SKSpriteNode()
    
    //Sprite Objects
    var bgObject = SKNode()
    
    
    override func didMove(to view: SKView) {
        bgTexture = SKTexture(imageNamed: "bg")
        
        
        createGame()
        createObjects()
        
    }
    func createObjects() {
           self.addChild(bgObject)
       }
    
    func createGame() {
        createBg()
    }
   
    
    func createBg() {
        bgTexture = SKTexture(imageNamed: "bg")
        
        let moveBg = SKAction.moveBy(x: 0, y: -bgTexture.size().height, duration: 3)
        let replaceBg = SKAction.moveBy(x: 0, y: bgTexture.size().height, duration: 0)
        let moveBgForever = SKAction.repeatForever(SKAction.sequence([moveBg, replaceBg]))
        
        
        for i in 0..<3 {
            bg = SKSpriteNode(texture: bgTexture)
            bg.position = CGPoint(x: size.height/1 + bgTexture.size().height * CGFloat(i), y: size.height/2)
            bg.size.height = self.frame.height
            bg.run(moveBgForever)
            bg.zPosition = -1
            
            bgObject.addChild(bg)
        }
    }
}
