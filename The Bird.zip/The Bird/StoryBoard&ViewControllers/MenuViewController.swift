import UIKit

protocol MenuDelegate {
    func playButtonPressed(_ viewController: MenuViewController)
}

class MenuViewController: UIViewController {
    
    var menuDelegate: MenuDelegate!
    
    @IBAction func playButton(_ sender: UIButton) {
        menuDelegate.playButtonPressed(self)
        //sender.transform = CGAffineTransform(scaleX: 0.9, y: 0.9)
    }
    
    
    @IBOutlet weak var playBTN: UIButton!
    
    @IBOutlet var marketBTN: UIButton!
    
    @IBOutlet var laderBTN: UIButton!
    
    @IBOutlet var settingsBTN: UIButton!
    
    @IBOutlet var noADSBTN: UIButton!
    
    @IBOutlet var falling: UIImageView!
    
    @IBOutlet var bird: UIImageView!
    
    @IBOutlet var rhomb: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
    
    
    
    
}
