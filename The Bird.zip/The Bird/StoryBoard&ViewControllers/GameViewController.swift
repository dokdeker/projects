//
//  GameViewController.swift
//  The Bird
//
//  Created by Evgeniy T on 30.04.2020.
//  Copyright © 2020 Evgeniy T. All rights reserved.
//

import UIKit
import SpriteKit
import GameplayKit

class GameViewController: UIViewController {

    var gameScene: GameScene!
//    var gameOverViewController: UIViewController!
    var gameOverViewController: GameOverViewController!
    var menuViewController: MenuViewController!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        gameOverViewController = storyboard?.instantiateViewController(withIdentifier: "gameOverViewController") as? GameOverViewController
        gameOverViewController.delegate = self
        
        
        
        menuViewController = storyboard?.instantiateViewController(withIdentifier: "menuViewController") as? MenuViewController
        menuViewController.menuDelegate = self
        
        if let view = self.view as! SKView? {
            // Load the SKScene from 'GameScene.sks'
            //let scene = GameScene(size: CGSize(width: 1080, height: 1920))
            if let scene = SKScene(fileNamed: "GameScene") {
                // Set the scale mode to scale to fit the window
                scene.scaleMode = .aspectFill
                
                gameScene = scene as? GameScene
                gameScene.gameViewControllerBridge = self
                gameScene.gameOverViewControllerBridge = gameOverViewController
                
                gameScene.menuViewControllerBridge = menuViewController
                
                // Present the scene
                view.presentScene(scene)
            }
            
            view.ignoresSiblingOrder = true
            
            view.showsFPS = false
            view.showsNodeCount = false
            view.showsPhysics = false
        }
    }
    
    override var shouldAutorotate: Bool {
        return true
    }
    
    override var supportedInterfaceOrientations: UIInterfaceOrientationMask {
        if UIDevice.current.userInterfaceIdiom == .phone {
            return .allButUpsideDown
        } else {
            return .all
        }
        
//        if UIDevice.current.userInterfaceIdiom == .pad {
//            return .allButUpsideDown
//        } else {
//            return .all
//        }
    }
    
    override var prefersStatusBarHidden: Bool {
        return true
    }
    
    
    
    func hideSceneGameOverAndRestart(viewController: UIViewController) {
        viewController.willMove(toParent: nil)
        viewController.removeFromParent()
        viewController.view.alpha = 1
        gameScene.birdExp = 0
        gameScene.imgListArray.removeAllObjects()
        UIView.animate(withDuration: 0.35, delay: 0, options: .curveEaseIn, animations: {
            viewController.view.alpha = 0
            self.gameScene.gameOverViewControllerBridge.view.center.y += 300
            self.gameScene.gameOverViewControllerBridge.gameOverCoinIcon.center.y = 22
            self.gameScene.gameOverViewControllerBridge.gameOverCoinLabel.center.y = 22
//            self.gameScene.gameOverViewControllerBridge.recordTextLabel.center.y = 205
//            self.gameScene.gameOverViewControllerBridge.bestScoreLabel.center.y = 255
                    }) { (completed) in
            self.gameScene.gameOverViewControllerBridge.gameOverScoreLaber.text = "0"
            self.gameScene.gameOverViewControllerBridge.gameOverCoinLabel.text = "0"
            self.gameScene.allCoin = 0
            viewController.view.removeFromSuperview()
        }
        
        gameScene.restartGame()
    }
    
    func hideSceneGameOverAndShowMenu(viewController: UIViewController) {
        viewController.willMove(toParent: nil)
        viewController.removeFromParent()
        viewController.view.alpha = 1
        gameScene.birdExp = 0
        gameScene.imgListArray.removeAllObjects()
        
        gameScene.fadeInMenuAfterGameOverAnimations()
        gameScene.menuViewControllerBridge.view.alpha = 1
        
        
        UIView.animate(withDuration: 0.3, delay: 0, options: .curveEaseIn, animations: {
            viewController.view.alpha = 0
            
            self.gameScene.gameOverViewControllerBridge.view.center.y += 300
            //self.gameScene.showMenu()
        }) { (completed) in
            self.gameScene.gameOverViewControllerBridge.gameOverScoreLaber.text = "0"
            self.gameScene.gameOverViewControllerBridge.gameOverCoinLabel.text = "0"
            self.gameScene.allCoin = 0
            viewController.view.removeFromSuperview()
        }
    }
    
    func hideSceneMenuAndShowGamePlay(viewController: UIViewController) {
        viewController.willMove(toParent: nil)
        viewController.removeFromParent()
        viewController.view.alpha = 1
        gameScene.restartGame()
        gameScene.fadeOutMenuBeforeGamePlayAnimation()
//        UIView.animate(withDuration: 0.3, delay: 0, options: .curveEaseIn, animations: {
//            //viewController.view.alpha = 0
//            //viewController.view.transform = CGAffineTransform(scaleX: 0.95, y: 0.95)
//            //self.gameScene.menuViewControllerBridge.playButton(playb: UIButton)
//            //self.playButtonPressed(MenuViewController)
//            //self.gameScene.menuViewControllerBridge.view.center.y += 15
//            //self.gameScene.zoomOutToActionCamera(zoomOutTo: 1, duration: 0.3)
//            self.gameScene.restartGame()
//        }) { (completed) in
//            viewController.view.removeFromSuperview()
//        }
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.4, execute: { [] in
            viewController.view.removeFromSuperview()
            
        })
    }
    
    
    
}
extension GameViewController: GameOverDelegate, MenuDelegate {
    func playButtonPressed(_ viewController: MenuViewController) {
        hideSceneMenuAndShowGamePlay(viewController: menuViewController)
    }
    

    
    func gameOverRestartButtonPressed(_ viewController: GameOverViewController) {
        hideSceneGameOverAndRestart(viewController: gameOverViewController)
    }
    func gameOverMenuPressed(_ viewController: GameOverViewController) {
        hideSceneGameOverAndShowMenu(viewController: gameOverViewController)
    }
    
    
}



