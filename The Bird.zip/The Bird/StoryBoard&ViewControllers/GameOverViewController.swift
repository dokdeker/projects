import UIKit
import Foundation









protocol GameOverDelegate {
    func gameOverRestartButtonPressed(_ viewController: GameOverViewController)

    func gameOverMenuPressed(_ viewController: GameOverViewController)
}


class GameOverViewController: UIViewController {
    
    var delegate: GameOverDelegate!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    @IBAction func backToMenu(_ sender: UIButton) {
        delegate.gameOverMenuPressed(self)
        //print("гы выходим в меню")
    }
    @IBAction func restart(_ sender: UIButton) {
        delegate.gameOverRestartButtonPressed(self)
        //print("гы заводим игру")
    }
    
    
    @IBOutlet weak var diagr: UIImageView!
//    func animDiagr() {
//        //diagr.image = UIImage(named: "3diagr.png")
//        var images = [UIImage]()
//        var animatedImage: UIImage!
//        for i in 0 ... 100 {
//            images.append(UIImage(named: "\(i)diagr.png")!)
//        }
//        animatedImage = UIImage.animatedImage(with: images, duration: 1.0)
//    }
    
    
    @IBOutlet weak var lvlLable: UILabel!
    @IBOutlet weak var gameOverCoinIcon: UIImageView!
    @IBOutlet weak var gameOverLable: UILabel!
    @IBOutlet weak var newRecordLabel: UILabel!
    @IBOutlet weak var gameOverCoinLabel: UILabel!
    @IBOutlet weak var gameOverScoreLaber: UILabel!
    @IBOutlet weak var bestScoreLabel: UILabel!
    @IBOutlet weak var recordTextLabel: UILabel!
    
    
    
}
